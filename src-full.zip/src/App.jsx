import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';

import Navbar from './Components/inc/Navbar';
import NavbarAfter from './Components/inc/NavbarAfter';
import NavbarAfterAdmin from './Components/inc/NavbarAfterAdmin';
import Home from './Components/pages/Home';
import Categories from './Components/pages/Categories';
import Footer from './Components/pages/Footer';
import Login from './Components/pages/Login';
import Register from './Components/pages/Register';
import Product from './Components/pages/Product';
import AUser from './Components/pages/AUser';
import ACategories from './Components/pages/ACategories';
import AProduct from './Components/pages/AProduct';
import ACoupons from './Components/pages/ACoupon';

import CatSofa from './Components/pages/CatSofa';
import CatBed from './Components/pages/CatBed';
import CatChair from './Components/pages/CatChair';
import CatCoffee from './Components/pages/CatCoffee';
import CatDining from './Components/pages/CatDining';
import CatLamp from './Components/pages/CatLamp';
import CatStudy from './Components/pages/CatStudy';
import CatSwing from './Components/pages/CatSwing';
import CatUnit from './Components/pages/CatUnit';

function App(props) {
    const [isLoggedIn, setLoggedIn] = useState(false);
    const [username, setUserName] = useState("");
    const [role, setRole] = useState("");

    let navbarComponent;

    console.log(isLoggedIn);
    console.log(role);
    if (isLoggedIn && role === 'A') {
        navbarComponent = <NavbarAfterAdmin isLoggedIn={isLoggedIn} />;
    } else if (isLoggedIn) {
        navbarComponent = <Navbar isLoggedIn={isLoggedIn} />;
    } else {
        navbarComponent = <NavbarAfter isLoggedIn={isLoggedIn} />;
    }

    return (
        <>
            <Router>
                <div>
                    {navbarComponent}
                    <Routes>
                        <Route
                            path="/home"
                            element={<Home isLoggedIn={isLoggedIn} setLoggedIn={setLoggedIn} role={role} setRole={setRole} />}
                        />
                        <Route path="/categories" element={<Categories />} />
                        <Route path="/footer" element={<Footer />} />
                        <Route
                            path="/login"
                            element={<Login isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} role={role} setRole={setRole} />}
                        />
                        <Route path="/register" element={<Register />} />
                        <Route
                            path="/product"
                            element={<Product isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} role={role} setRole={setRole} />}
                        />
                        <Route path="/auser" element={<AUser />} />
                        <Route path="/acategories" element={<ACategories />} />
                        <Route path="/aproducts" element={<AProduct />} />
                        <Route path="/acoupons" element={<ACoupons />} />

                        <Route path="/catsofa" element={<CatSofa />} />
                        <Route path="/catbed" element={<CatBed />} />
                        <Route path="/catlamp" element={<CatLamp />} />
                        <Route path="/catchair" element={<CatChair />} />
                        <Route path="/catstudy" element={<CatStudy />} />
                        <Route path="/catdining" element={<CatDining />} />
                        <Route path="/catcoffee" element={<CatCoffee />} />
                        <Route path="/catswing" element={<CatSwing />} />
                        <Route path="/catunit" element={<CatUnit />} />

                    </Routes>
                </div>
            </Router>
        </>
    );
}

export default App;