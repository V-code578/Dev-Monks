import React from 'react';
import Logo from '../Assets/LogoPng.png';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

//After login

function Navbar(props) {
    const userName = props.userName;
        return (
            <>
                <nav id="navbar-example2" className="navbar navbar-light bg-light">
                    <a className="navbar-brand" href="#State"><img src={Logo} className="logo" alt="..." /></a>
                    <ul className="nav nav-pills">
                        <li>
                            <Link to="/home" className="nav-link">Home</Link>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#categories">Categories</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#about">About Us</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#footer">Contact Us</a>
                        </li>
                        <li>
                            <a className="nav-link" href="#">Hello User!</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/home" onClick={() => props.setLoggedIn(false)}>Logout</a>
                        </li>
                        <li>
                            <Link to="/product" className="nav-link">Products</Link>
                        </li>
                    </ul>
                </nav>
            </>
        );
    }

export default Navbar;