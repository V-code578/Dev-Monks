import React from 'react';
import Logo from '../Assets/LogoPng.png';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import AdminUser from '../pages/AUser';


function NavbarAfterAdmin(props) {
    const userName = props.userName;
    return (
        <>
            <nav id="navbar-example2" className="navbar navbar-light bg-light">
                <a className="navbar-brand" href="#State"><img src={Logo} className="logo" alt="..." /></a>
                <ul className="nav nav-pills">
                    <li>
                        <Link to="/home" className="nav-link">Home</Link>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#categories">Categories</a>
                    </li>
                    <li>
                        <Link to="/product" className="nav-link">Products</Link>
                    </li>
                    <li>
                        <a className="nav-link" href="#">Hello Admin!</a>
                    </li>
                  
     
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Operations
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <Link to="/product" className="nav-link">Users</Link>
                            </li>
                            <li>
                                <Link to="/ACategories" className="nav-link">Categories</Link>
                            </li>
                            <li>
                                <Link to="/aproducts" className="nav-link">Products</Link>
                            </li>
                            <li>
                                <Link to="/acoupons" className="nav-link">Coupons</Link>
                            </li>
                        </ul>
                    </li>

                    <li className="nav-item">
                        <a className="nav-link" href="/home" onClick={() => props.setLoggedIn(false)}>Logout</a>
                    </li>
                </ul>
            </nav>
        </>
    );
}

export default NavbarAfterAdmin;