import React from 'react';

function Footer() {
    return (
        <div className="container">
            <div className="card mt-4">
                <div className="card-body">
                    <h2>Footer</h2>
                </div>
            </div>
        </div>
    );
}
export default Footer;