import React, { useState, useEffect } from 'react';

import TVUnit1 from '../Assets/TV Units/TVUnit1.jpg';
import TVUnit2 from '../Assets/TV Units/TVUnit2.jpg';
import TVUnit3 from '../Assets/TV Units/TVUnit3.jpg';
import TVUnit4 from '../Assets/TV Units/TVUnit4.jpg';
import TVUnit5 from '../Assets/TV Units/TVUnit5.jpg';
import TVUnit6 from '../Assets/TV Units/TVUnit6.jpg';

 const ProductList = ({ products, addToCart, addToWishlist }) => {
        const tvunitImages = [TVUnit1, TVUnit2, TVUnit3, TVUnit4, TVUnit5, TVUnit6];

        const shuffleArray = (array) => {
            const shuffledArray = array.slice(); // Copy the array to avoid mutating the original
            for (let i = shuffledArray.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [shuffledArray[i], shuffledArray[j]] = [shuffledArray[j], shuffledArray[i]];
            }
            return shuffledArray;
        };

        const [shuffledTVUnitImages, setShuffledTVUnitImages] = useState([]);

        useEffect(() => {
            setShuffledTVUnitImages(shuffleArray(tvunitImages));
        }, [products]);

        const renderProductImage = (productName) => {
            const lowerProductName = productName.toLowerCase();
            let image;

            if (lowerProductName.includes('tv unit')) {
                const imageIndex = Math.floor(Math.random() * shuffledTVUnitImages.length);
                image = shuffledTVUnitImages[imageIndex];
            }
            return <img src={image} className="img-fluid rounded-start" alt={productName} />
        };
        return (
            <div>
                <br />
                <h2 className="main-heading">TV Units</h2>
                <div className="underline"></div> <br />
                <ul style={{ listStyleType: 'none', padding: 0 }} className="products">
                    {products.map((product) => (
                        <li key={product.productId}>
                            <div className="card mb-12" style={{ width: '1050px' }}>
                                <div className="row g-0">
                                    <div className="col-md-7">
                                        {renderProductImage(product.productName)}
                                    </div>
                                    <div className="col-md-5">
                                        <div className="card-body">
                                            <h3 className="card-title">{product.productName}</h3>
                                            <p className="card-text">{product.description}</p>
                                            <p>Price: ${product.price.toFixed(2)}</p>
                                            <button onClick={() => addToCart(product.productId)}>Add to Cart</button>{' '}
                                            <button onClick={() => addToWishlist(product.productId)}>Add to Wishlist</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    ))}
                </ul>
            </div>
        );
    };
function CatUnit() {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        fetch("https://localhost:7012/api/Product/ProductByCategory/9")
            .then((response) => response.json())
            .then((data) => {
                setProducts(data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);

    const redirectToLogin = () => {
        navigate('/login');
    };

    const isUserLoggedIn = () => {
        const user = localStorage.getItem('user');
        return !!user;
    };

    const addToCart = (productId) => {
        if (!isUserLoggedIn()) {
            redirectToLogin();
            return;
        }

        const selectedProduct = products.find((product) => product.productId === productId);
        setCart(selectedProduct);
        navigate('/categories'); //cart
    };

    const addToWishlist = (productId) => {
        if (!isUserLoggedIn()) {
            redirectToLogin();
            return;
        }

        const selectedProduct = products.find((product) => product.productId === productId);
        setWishlist(selectedProduct);

        navigate('/categories'); //wishlist
    };

    return (
        <div>
            <ProductList products={products} addToCart={addToCart} addToWishlist={addToWishlist} />
        </div>
    );
}
export default CatUnit;