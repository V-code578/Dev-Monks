import React from 'react';
import Slider from '../inc/Slider';
import Sofa from '../Assets/SofaCat.jpg';
import Bed from '../Assets/BedCat.jpg';
import Light from '../Assets/LightCap.jpg';
import Chair from '../Assets/Chair2Cat.jpg';
import Study from '../Assets/StudyCat.jpg';
import Dining from '../Assets/DiningCat.jpg';
import Coffee from '../Assets/CoffeeCap.jpg';
import Swing from '../Assets/SwingCat.jpg';
import Unit from '../Assets/UnitCat.jpg';
import Van from '../Assets/About1.jpg';
import Design from '../Assets/About2.jpg';

import {  Link } from 'react-router-dom';



function Home() {

    return (
        <div>
            <div id="State">
                <Slider />
            </div>
            <section className="section">
                <div id="categories">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12 text-center">
                                <h3 className="main-heading">
                                    Explore Our Furniture Range
                                </h3>
                                <div className="underline"></div>
                            </div>
                        </div>
                    </div>

                    <div className="Categories">
                        <div className="container">
                            <div className="row">
                                <div className="col-md-4">
                                <Link to = "/catsofa" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }} >
                                        <img className="card-img-top" src={Sofa} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Sofas</p>
                                        </div>
                                        </div>
                                    </Link>
                                </div>

                                <div className="col-md-4">
                                 <Link to="/catbed" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Bed} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Beds</p>
                                        </div>
                                        </div>
                                    </Link>
                                    </div>

                                <div className="col-md-4">
                                    <Link to="/catlamp" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Light} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Lighting</p>
                                        </div>
                                        </div>
                                    </Link>
                                </div>

                            
                                <div className="col-md-4">
                                    <Link to="/catchair" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Chair} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Seating</p>
                                        </div>
                                        </div>
                                    </Link>
                                </div>

                                <div className="col-md-4">
                                    <Link to="/catstudy" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Study} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Study Tables</p>
                                        </div>
                                        </div>
                                    </Link>
                                </div>

                                <div className="col-md-4">
                                    <Link to="/catdining" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Dining} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Dining</p>
                                        </div>
                                        </div>
                                    </Link>
                                </div>

                                <div className="col-md-4">
                                    <Link to="/catcoffee" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Coffee} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Coffee Tables</p>
                                        </div>
                                        </div>
                                    </Link>
                                </div>

                                <div className="col-md-4">
                                    <Link to="/catswing" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Swing} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Swing Chairs</p>
                                        </div>
                                        </div>
                                    </Link>
                                </div>

                                <div className="col-md-4">
                                    <Link to="/catunit" className="card-block" >
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Unit} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">TV Units</p>
                                        </div>
                                        </div>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>

                    <br /><br />
                    <div className="underline1"></div>
                </div>

                <div id="about">
                    <div className="containerSecret">
                        <div className="row">
                            <div className="col-md-12 text-center">
                                <h3 className="oursecret">
                                    Our Story
                                </h3>
                                <div className="underline"></div>
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-md-5">
                            <img className="align-self-center mr-3" src={Van} alt="Generic placeholder image" />
                        </div>
                        <div className="col-md-7">
                            <div className="media-body">
                                <p className="heading1">Our Best In Class <br />Big-Box Supply Chain</p>
                                <p className="body1">Indias furniture market used to be hyperlocal. FHSquare disrupted the very nature <br /> of this market by creating Indias largest big-box supply chain network. <br />FHSquareLogistics provides first-mile and last-mile logistics services to <br />buyers and sellers in over 500 cities. FHSquareLogistics has successfully delivered <br /> more than 10 million shipments in the last decade. After all, FHSquare is about <br /><b><i> Happy Furniture To You.</i></b></p>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div className="row">
                        <div className="col-md-6">
                            <div className="media-body">
                                <p className="heading2">Commercial Design &<br />Builder Services</p>
                                <p className="body2">Our team specializes in crafting designs that align with your brand identity, optimizing workspaces with quality furniture. Whether you're furnishing offices, restaurants, or other commercial spaces, our services cater to diverse needs. We prioritize a seamless blend of style and functionality to enhance the overall user experience.</p>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <img className="align-self-center mr-3" src={Design} alt="Generic placeholder image" />
                        </div>
                    </div>
                </div>
                <br />
                <div id="footer">
                    <footer className="bg-dark text-white text-center">
                        <div className="container p-4">
                            <div className="row">
                                <div className="col-md-12">
                                    <h4>Contact Us</h4>
                                    <p>Revanth, Pujitha, Vinay, Vishwanath </p>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-12">
                                    {/* Add your social media icons */}
                                    <a href="#" className="text-white me-4">
                                        <i className="fab fa-youtube"></i>
                                    </a>
                                    <a href="#" className="text-white me-4">
                                        <i className="fab fa-twitter"></i>
                                    </a>
                                    <a href="#" className="text-white me-4">
                                        <i className="fab fa-instagram"></i>
                                    </a>
                                    <a href="#" className="text-white me-4">
                                        <i className="fab fa-facebook"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-12">
                                    <p>
                                        <a href="#" className="text-white me-4">Privacy Policy</a>
                                        <a href="#" className="text-white me-4">Terms of Use</a>
                                        <a href="#" className="text-white me-4">Data & Security</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </footer>
                </div>

            </section>
        </div>
    );
}
export default Home;