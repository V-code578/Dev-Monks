import React from 'react';
import { useState, useEffect } from 'react';


function ACategories() {
    const [categories, setCategories] = useState([]);
    const [category, setCategory] = useState({ categoryId: "", categoryName: "" });

    useEffect(() => {
        fetch("https://localhost:7012/api/Category")
            .then(result => result.json())
            .then(result => {
                setCategories(result);
            });
    }, []);

    const deleteCategory = (categoryId) => {
        fetch('https://localhost:7012/api/Category/' + categoryId, {
            method: 'DELETE',
        }).then(result => result.text()).then(result => {
            alert("Category deleted");
            setCategories(categories.filter(c => c.categoryId !== categoryId));
        });
    }

    const fetchAllCategories = () => {
        fetch("https://localhost:7012/api/Category")
            .then(result => result.json())
            .then(result => {
                setCategories(result);
            });
    };

    const addCategory = () => {
        fetch("https://localhost:7012/api/Category", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(category)
        }).then(result => result.json())
            .then(result => {
                alert("Category "+ category.categoryName + " added");
                setCategories([...categories, result]);
                setCategory({ categoryName: "" });
            });
    };

 /*   const updateCategory = (categoryId) => {
        fetch('https://localhost:7012/api/Category/' + categoryId, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(category)
        }).then(result => result.json())
            .then(result => {
                alert("Category updated");
                setCategories(categories.map(c => c.categoryId === categoryId ? result : c));
                setCategory({  categoryName: "" });
            });
    };*/

    const showCategoryById = (categoryId) => {
        fetch('https://localhost:7012/api/Category/ById/' + categoryId)
            .then(result => result.json())
            .then(result => {
                alert(`Category Id: ${result.categoryId}\nCategory Name: ${result.categoryName}`);
            });
    };

    return (
        <>
            <div className="container mt-4">
                <h2 className="main-heading">Category Form</h2>
                <div className="underline"></div>
            <form>
                <div className="mb-3">
                    <label htmlFor="categoryId" className="form-label">Category ID:</label>
                    <input type="text" className="form-control" id="categoryId" value={category.categoryId}
                        onChange={(e) => setCategory(prev => ({ ...prev, categoryId: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label htmlFor="categoryName" className="form-label">Category Name:</label>
                    <input type="text" className="form-control" id="categoryName" value={category.categoryName}
                        onChange={(e) => setCategory(prev => ({ ...prev, categoryName: e.target.value }))} />
                </div>
                <button type="button" className="btn btn-primary" onClick={fetchAllCategories}>Show All Categories</button>
                <button type="button" className="btn btn-success ms-2" onClick={addCategory}>Add Category</button>
                {/*               <button type="button" className="btn btn-warning ms-2" onClick={() => updateCategory(category.categoryId)}>Update Category</button>  */}
                <button type="button" className="btn btn-info ms-2" onClick={() => showCategoryById(category.categoryId)}>Show Single Category</button>
            </form>
            <h3 className="mt-4">List of Categories</h3>
            <table className="table">
                <thead>
                    <tr>
                        <th>Category ID</th>
                        <th>Category Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {categories.map(category => (
                        <tr key={category.categoryId}>
                            <td>{category.categoryId}</td>
                            <td>{category.categoryName}</td>
                            <td>
                                <button type="button" className="btn btn-danger" onClick={() => deleteCategory(category.categoryId)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            </div>
        </>
    );
}

export default ACategories;