import React, { useState, useEffect } from 'react';
import Sofa from '../Assets/SofaCat.jpg';
import Bed from '../Assets/BedCat.jpg';
import Light from '../Assets/LightCap.jpg';
import Chair from '../Assets/Chair2Cat.jpg';
import Study from '../Assets/StudyCat.jpg';
import Dining from '../Assets/DiningCat.jpg';
import Coffee from '../Assets/CoffeeCap.jpg';
import Swing from '../Assets/SwingCat.jpg';
import Unit from '../Assets/UnitCat.jpg';

function Categories() {

    return (
        <>
            <h2>dsds</h2>
        </>
    );
};

export default Categories;
