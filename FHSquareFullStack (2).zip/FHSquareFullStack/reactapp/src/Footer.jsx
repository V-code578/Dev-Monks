import React from 'react';

const Footer = () => {
    return (
        <footer className="bg-dark text-white text-center">
            <div className="container p-4">
                <div className="row">
                    <div className="col-md-12">
                        <h4>Contact Us</h4>
                        <p>teamdevmonks@gmail.com </p>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-12">
                        {/* Add your social media icons */}
                        <a href="#" className="text-white me-4">
                            <i className="fab fa-youtube"></i>
                        </a>
                        <a href="#" className="text-white me-4">
                            <i className="fab fa-twitter"></i>
                        </a>
                        <a href="#" className="text-white me-4">
                            <i className="fab fa-instagram"></i>
                        </a>
                        <a href="#" className="text-white me-4">
                            <i className="fab fa-facebook"></i>
                        </a>
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-12">
                        <p>
                            <a href="#" className="text-white me-4">Privacy Policy</a>
                            <a href="#" className="text-white me-4">Terms of Use</a>
                            <a href="#" className="text-white me-4">Data & Security</a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
