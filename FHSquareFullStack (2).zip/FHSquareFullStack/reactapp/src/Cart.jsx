//import React, { useState, useEffect } from 'react';
//import { Button } from 'react-bootstrap';

//const Cart = (props) => {
//    const [cart, setCart] = useState({ userName: "", productId: 0, quantity: 0 });
//    //const [name, setName] = useState({ userName:" " });
//    const username = props.username;
//    useEffect(() => {
//        // Fetch cart data when the component mounts
//        getCartData();
//    }, []);

//    const getCartData = async () => {
//        try {
//            //const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoicHVqaUBnbWFpbC5jb20iLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJVIiwiZXhwIjoxNzAwNTYzMzM4LCJpc3MiOiJodHRwczovL3d3dy52aW5heS5jb20iLCJhdWQiOiJodHRwczovL3d3dy52aW5heS5jb20ifQ.hW-1VlEMRncUWGs9WkutSnI8nJMmF8e4QmXqcRG3RTg';
//            alert(username);
//            const response = await fetch('GET: https://localhost:7012/api/Cart/CartByUserName/' + username, {
//                method: 'GET',
//                headers: {
//                    'Content-Type': 'application/json',
//                    //'Authorization': `Bearer ${token}`,
//                },

//            });

//            if (!response.ok) {
//                throw new Error('Failed to fetch cart data');
//            }

//            const cartData = await response.json();
//             console.log(cartData);
//            setCart(cartData);

//        } catch (error) {
//            console.error('Error fetching cart data:', error.message);
//        }
//    };

//    const addToCart = async (productId, quantity) => {
//        try {

//            const response = await fetch('http://localhost:7012/api/cart/add', {
//                method: 'POST',
//                headers: {
//                    'Content-Type': 'application/json',
//                },
//                body: JSON.stringify({ productId, quantity }),
//            });

//            if (!response.ok) {
//                throw new Error('Failed to add to cart');
//            }

//            // Refresh cart data after adding
//            getCartData();
//        } catch (error) {
//            console.error('Error adding to cart:', error.message);
//        }
//    };

//    const removeFromCart = async (productId) => {
//        try {

//            const response = await fetch('http://localhost:7012/api/cart/remove', {
//                method: 'DELETE',
//                headers: {
//                    'Content-Type': 'application/json',
//                },
//                body: JSON.stringify({ productId }),
//            });

//            if (!response.ok) {
//                throw new Error('Failed to remove from cart');
//            }

//            // Refresh cart data after removing
//            getCartData();
//        } catch (error) {
//            console.error('Error removing from cart:', error.message);
//        }
//    };

//    const clearCart = async () => {
//        try {

//            const response = await fetch('http://localhost:7012/api/cart/clear', {
//                method: 'DELETE',
//                headers: {
//                    'Content-Type': 'application/json',
//                },
//            });

//            if (!response.ok) {
//                throw new Error('Failed to clear cart');
//            }

//            // Refresh cart data after clearing
//            getCartData();
//        } catch (error) {
//            console.error('Error clearing cart:', error.message);
//        }
//    };
//    const handleBuyNow = async () => {
//        try {
//            // Call your server-side endpoint to handle the purchase logic
//            const response = await fetch('https://localhost:7012/api/Cart/BuyNow/' + username, {
//                method: 'POST',
//                headers: {
//                    'Content-Type': 'application/json',
//                },
//            });

//            if (!response.ok) {
//                throw new Error('Failed to complete the purchase');
//            }

//            // Optionally, you can redirect to a thank you page or perform other actions
//            console.log('Purchase successful!');
//        } catch (error) {
//            console.error('Error during purchase:', error.message);
//        }
//    };


//    return (
//        <div>
//            <h2>Cart</h2>
//            {cart ? (
//                <>
//                    <ul>
//                        <li key={cart.productId}>
//                            UserName: {cart.userName}--
//                            Quantity: {cart.quantity}--
//                            <Button onClick={() => removeFromCart(cart.productId)}>Remove</Button>
//                        </li>
//                    </ul>
//                    {<Button onClick={clearCart}>Clear Cart</Button>}
//                    {<Button onClick={handleBuyNow}>Buy Now</Button>}
//                </>
//            ) : (
//                <p>Your cart is empty.</p>
//            )}
//        </div>
//    );
//};

//export default Cart;

import React, { useState, useEffect } from 'react';
import { Button } from 'react-bootstrap';

const Cart = (props) => {
    const [cart, setCart] = useState({ username: "", productId: 0, quantity: 0 });
    const username = props.username;

    useEffect(() => {
        // Fetch cart data when the component mounts
        getCartData();
    }, []);

    const getCartData = async () => {
        try {
            const response = await fetch('https://localhost:7012/api/Cart/CartByUsername/' + username, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            console.log('Response status:', response.status);

            if (!response.ok) {
                throw new Error('Failed to fetch cart data');
            }

            const cartData = await response.json();
            console.log('Cart data:', cartData);

            setCart(cartData);
        } catch (error) {
            console.error('Error fetching cart data:', error.message);
        }
    };


    const addToCart = async (productId, quantity) => {
        try {
            const response = await fetch('http://localhost:7012/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ productId, quantity }),
            });

            if (!response.ok) {
                throw new Error('Failed to add to cart');
            }

            // Refresh cart data after adding
            getCartData();
        } catch (error) {
            console.error('Error adding to cart:', error.message);
        }
    };

    const removeFromCart = async (productId) => {
        try {
            const response = await fetch('http://localhost:7012/api/cart/remove', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ productId }),
            });

            if (!response.ok) {
                throw new Error('Failed to remove from cart');
            }

            // Refresh cart data after removing
            getCartData();
        } catch (error) {
            console.error('Error removing from cart:', error.message);
        }
    };

    const clearCart = async () => {
        try {
            const response = await fetch('http://localhost:7012/api/cart/clear', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to clear cart');
            }

            // Refresh cart data after clearing
            getCartData();
        } catch (error) {
            console.error('Error clearing cart:', error.message);
        }
    };

    const handleBuyNow = async () => {
        try {
            const response = await fetch('https://localhost:7012/api/Cart/BuyNow/' + username, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to complete the purchase');
            }

            console.log('Purchase successful!');
        } catch (error) {
            console.error('Error during purchase:', error.message);
        }
    };

    const renderCartItems = () => (
        <>
            <ul>
                <li key={cart.productId}>
                    UserName: {cart.username}--
                    Quantity: {cart.quantity}--
                    <Button onClick={() => removeFromCart(cart.productId)}>Remove</Button>
                </li>
            </ul>
            {<Button onClick={clearCart}>Clear Cart</Button>}
            {<Button onClick={handleBuyNow}>Buy Now</Button>}
        </>
    );

    return (
        <div>
            <h2>Cart</h2>
            {cart ? renderCartItems() : <p>Your cart is empty.</p>}
        </div>
    );
};

export default Cart;
