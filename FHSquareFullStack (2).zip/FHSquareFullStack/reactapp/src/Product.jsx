import React, { useState, useEffect } from 'react';
import test1 from './assets/LogoPng.png';

const Product = (props) => {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        // Fetch product data when the component mounts
        getProducts();
    }, []);

    const getProducts = async () => {
        try {
            const response = await fetch('https://localhost:7012/api/Product/allproducts/', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    //'Authorization': `Bearer ${token} `,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch products');
            }

            const productData = await response.json();
            setProducts(productData);
        } catch (error) {
            console.error('Error fetching products:', error.message);
        }
    };

    return (
        <div>
            <h2>Product List</h2>
            <ul>
                {Array.isArray(products) && products.length > 0 ? (
                    products.map((product) => (
                        <li key={product.productId}>
                            <div className="card mb-3" style={{ width: '540px'}}>
                                <div className="row g-0">
                                    <div className="col-md-5">
                                        <img src={test1} className="img-fluid rounded-start" alt="..." />
                                    </div>
                                    <div className="col-md-7">
                                        <div className="card-body">
                                            <h3 className="card-title">{product.productName}</h3>
                                            <p className="card-text">{product.description}</p>
                                            <p>Price: ${product.price.toFixed(2)}</p>
                                            <p>Stock Quantity: {product.stockQuantity}</p>
                                            <a href="#" className="btn btn-primary">Add To Cart</a>
                                            <a href="#" className="btn btn-primary">Add To WishList</a>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    ))
                ) : (
                    <p>No products available</p>
                )}
            </ul>
        </div>
    );
};

export default Product;
