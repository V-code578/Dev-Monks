import React from 'react';
import { Carousel } from 'react-bootstrap';

const MyCarousel = () => {
    return (
        <Carousel interval={3000}>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src="/assets/Gif03.gif"
                    alt="First slide"
                    width="100%"
                    height="450"
                />
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src="/assets/Gif04.gif"
                    alt="Second slide"
                    width="100%"
                    height="450"
                />
            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src="/assets/Gif05.gif"
                    alt="Third slide"
                    width="100%"
                    height="450"
                />
            </Carousel.Item>
        </Carousel>
    );
};

export default MyCarousel;
