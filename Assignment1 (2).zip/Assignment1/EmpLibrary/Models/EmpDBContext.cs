﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLibrary.Models
{
    public class EmpDBContext : DbContext
    {
        public EmpDBContext()
        {
            
        }

        public EmpDBContext(DbContextOptions<EmpDBContext> options) : base(options)
        {
            
        }

        public DbSet<Employee> Employees { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; database=EmployeeDB; Integrated security=true");
        }
    }
}
