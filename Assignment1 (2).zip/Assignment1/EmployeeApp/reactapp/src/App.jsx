import React from 'react';
import Dashboard from './Dashboard';

function App() {
    return (
        <div>
            <h1>My Application</h1>
            <Dashboard />
        </div>
    );
}

export default App;