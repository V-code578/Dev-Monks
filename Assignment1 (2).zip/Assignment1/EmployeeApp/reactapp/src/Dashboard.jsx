import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Dashboard() {
    const [employees, setEmployees] = useState([]);
    const [employee, setEmployee] = useState({ empId: 0, empName: '', age: 0, salary: 0 });
    const [saved, setSaved] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        fetchData();
    }, [saved]);

    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:5106/api/Employee');
            setEmployees(response.data);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const saveEmployee = async (event) => {
        event.preventDefault();
        try {
            await axios.post('http://localhost:5106/api/Employee', employee);
            alert('New employee added');
            setSaved(true);
        } catch (error) {
            console.error('Error saving employee:', error);
        }
    };

    const updateEmployee = async () => {
        try {
            await axios.put(`http://localhost:5106/api/Employee/${employee.empId}`, employee);
            alert('Employee details updated');
            setSaved(true);
        } catch (error) {
            console.error('Error updating employee:', error);
        }
    };

    const deleteEmployee = async () => {
        try {
            await axios.delete(`http://localhost:5106/api/Employee/${employee.empId}`);
            alert('Employee deleted');
            setSaved(true);
        } catch (error) {
            console.error('Error deleting employee:', error);
        }
    };

    const handleSearch = (event) => {
        setSearchTerm(event.target.value);
    };

    const filteredEmployees = employees.filter((emp) =>
        emp.empName.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-body">
                            <h3 className="card-title">Employee Form</h3>
                            <form onSubmit={saveEmployee}>
                                <div className="mb-3">
                                    <label htmlFor="empId" className="form-label">
                                        Emp Id:
                                    </label>
                                    <input
                                        type="number"
                                        className="form-control"
                                        id="empId"
                                        value={employee.empId}
                                        onChange={(e) =>
                                            setEmployee((prevState) => ({ ...prevState, empId: e.target.value }))
                                        }
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="empName" className="form-label">
                                        Emp Name:
                                    </label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        id="empName"
                                        value={employee.empName}
                                        onChange={(e) =>
                                            setEmployee((prevState) => ({ ...prevState, empName: e.target.value }))
                                        }
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="age" className="form-label">
                                        Age:
                                    </label>
                                    <input
                                        type="number"
                                        className="form-control"
                                        id="age"
                                        value={employee.age}
                                        onChange={(e) =>
                                            setEmployee((prevState) => ({ ...prevState, age: e.target.value }))
                                        }
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="salary" className="form-label">
                                        Salary:
                                    </label>
                                    <input
                                        type="number"
                                        className="form-control"
                                        id="salary"
                                        value={employee.salary}
                                        onChange={(e) =>
                                            setEmployee((prevState) => ({ ...prevState, salary: e.target.value }))
                                        }
                                    />
                                </div>
                                <button type="submit" className="btn btn-primary me-2">
                                    Save
                                </button>
                                <button type="button" className="btn btn-primary me-2" onClick={updateEmployee}>
                                    Update
                                </button>
                                <button type="button" className="btn btn-danger" onClick={deleteEmployee}>
                                    Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="card">
                        <div className="card-body">
                            <h3 className="card-title">List of Employees</h3>
                            <div className="mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Search by Employee Name"
                                    value={searchTerm}
                                    onChange={handleSearch}
                                />
                            </div>
                            <div className="table-responsive">
                                <table className="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Emp Id</th>
                                            <th>Name</th>
                                            <th>Age</th>
                                            <th>Salary</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {filteredEmployees.map((emp) => (
                                            <tr key={emp.empId}>
                                                <td>{emp.empId}</td>
                                                <td>{emp.empName}</td>
                                                <td>{emp.age}</td>
                                                <td>{emp.salary}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Dashboard;