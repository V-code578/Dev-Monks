import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom';

function AdminHome() {
    return (
        <div className="container mt-4">
            <h1 className="text-black">Welcome, Admin!</h1>
            <nav className="navbar navbar-expand-lg navbar-light bg-black">
                <div className="container-fluid">
                    <Link className="navbar-brand text-white" to="/">Admin Dashboard</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav">
                            <li className="nav-item">
                                <Link className="nav-link text-white" to="/AdminUser">Admin Users</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-white" to="/AdminCategories">Categories</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-white" to="/AdminProducts">Products</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-white" to="/AdminOrders">Orders</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link text-white" to="/AdminCoupons">Coupons</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    );
}

export default AdminHome;