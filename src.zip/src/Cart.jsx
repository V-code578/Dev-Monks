import React, { useState, useEffect } from 'react';
import { Button } from 'react-bootstrap';

const Cart = (props) => {
    const [cart, setCart] = useState({ username: "", productId: 0, quantity: 0 });
    const username = props.username;

    useEffect(() => {
        // Fetch cart data when the component mounts
        getCartData();
    }, []);

    const getCartData = async () => {
        try {
            const response = await fetch('https://localhost:7012/api/Cart/CartByUserName/' + username, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            console.log('Response status:', response.status);

            if (!response.ok) {
                throw new Error('Failed to fetch cart data');
            }

            const cartData = await response.json();
            console.log('Cart data:', cartData);

            setCart(cartData);
        } catch (error) {
            console.error('Error fetching cart data:', error.message);
        }
    };


    const addToCart = async (productId, quantity) => {
        try {
            const response = await fetch('http://localhost:7012/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ productId, quantity }),
            });

            if (!response.ok) {
                throw new Error('Failed to add to cart');
            }

            // Refresh cart data after adding
            getCartData();
        } catch (error) {
            console.error('Error adding to cart:', error.message);
        }
    };

    const removeFromCart = async (productId) => {
        try {
            const response = await fetch('http://localhost:7012/api/cart/remove', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ productId }),
            });

            if (!response.ok) {
                throw new Error('Failed to remove from cart');
            }

            // Refresh cart data after removing
            getCartData();
        } catch (error) {
            console.error('Error removing from cart:', error.message);
        }
    };

    const clearCart = async () => {
        try {
            const response = await fetch('http://localhost:7012/api/cart/clear', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to clear cart');
            }

            // Refresh cart data after clearing
            getCartData();
        } catch (error) {
            console.error('Error clearing cart:', error.message);
        }
    };

    const handleBuyNow = async () => {
        try {
            const response = await fetch('https://localhost:7012/api/Cart/BuyNow/' + username, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to complete the purchase');
            }

            console.log('Purchase successful!');
        } catch (error) {
            console.error('Error during purchase:', error.message);
        }
    };

    const renderCartItems = () => (
        <>
            <ul>
                <li key={cart.productId}>
                    UserName: {cart.username}--
                    Quantity: {cart.quantity}--
                    <Button onClick={() => removeFromCart(cart.productId)}>Remove</Button>
                </li>
            </ul>
            {<Button onClick={clearCart}>Clear Cart</Button>}
            {<Button onClick={handleBuyNow}>Buy Now</Button>}
        </>
    );

    return (
        <div>
            <h2>Cart</h2>
            {cart ? renderCartItems() : <p>Your cart is empty.</p>}
        </div>
    );
};

export default Cart;
