import React, { useState } from 'react';

const SearchBar = ({ onSearch }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const handleSearch = () => {
        // Perform search logic here
        // You can pass the search term to the parent component using the onSearch callback
        onSearch(searchTerm);
    };

    return (
        <section className="intro">
            <div className="bg-image-vertical h-100" >
                <div className="mask d-flex align-items-center h-100">
                    <div className="container">

                        <div className="card">
                            <div className="card-body">
                                <div className="row justify-content-center">
                                    <div className="col-md-6 mb-3 mb-md-0">
                                        <div id="basic" className="form-outline">
                                            <input type="text" id="form1" className="form-control form-control-lg" onChange={(e) => setSearchTerm(e.target.value)} />
                                            <label className="form-label" htmlFor="form1">What are you looking for?</label>
                                        </div>
                                    </div>
                                    <div className="col-md-4 mb-3 mb-md-0">
                                        <div id="location" className="form-outline">
                                            <input type="text" id="form2" className="form-control form-control-lg" />
                                            <label className="form-label" htmlFor="form2">Location</label>
                                        </div>
                                    </div>
                                    <div className="col-md-2">
                                        <button className="btn btn-secondary btn-block btn-lg" type="button" onClick={handleSearch}>Search</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default SearchBar;