import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function Register() {
    const [username, setUsername] = useState({ Username: '', error: '' });
    const [password, setPassword] = useState({ Password: '', error: '' });
    const [confirmPassword, setConfirmPassword] = useState({ ConfirmPassword: '', error: '' });
    const [role, setRole] = useState({ Role: '', error: '' });
    const [registrationError, setRegistrationError] = useState('');

    const handleUsernameChange = (event) => {
        const value = event.target.value;
        setUsername({ Username: value, error: '' });
    };

    const handlePasswordChange = (event) => {
        const value = event.target.value;
        setPassword({ Password: value, error: '' });
    };

    const handleConfirmPasswordChange = (event) => {
        const value = event.target.value;
        setConfirmPassword({ ConfirmPassword: value, error: '' });
    };

    const handleRoleChange = (event) => {
        const value = event.target.value;
        setRole({ Role: value, error: '' });
    };

    const handleRegister = async () => {
        // Validation logic
        if (!username.Username || !password.Password || !confirmPassword.ConfirmPassword || !role.Role) {
            setRegistrationError('All fields are required');
            return;
        }

        if (password.Password !== confirmPassword.ConfirmPassword) {
            setRegistrationError('Password and Confirm Password must match');
            return;
        }

        // Call the registration API
        try {
            const user = {
                UserName: username.Username,
                Password: password.Password,
                Role: role.Role
            };

            console.log('Registration data:', user);

            const response = await fetch('https://localhost:7012/api/User/', {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(user)
            });
            

            console.log('Registration response:', response);

            if (response.status === 200) {
                console.log('Registration successful!');
            } else {
                throw new Error(`Registration failed with status ${response.status}`);
            }
        } catch (error) {
            console.error('Registration error:', error);
            setRegistrationError('Registration failed. Please try again later.');
        }
        alert("Hi");
    };




    return (
        <div className="container">
            <div className="w-50 mt-5 mx-auto">
                <h2>Register</h2>
                <div className="errors">
                    <p>Fields marked with * are mandatory</p>
                    {registrationError !== '' && <li>{registrationError}</li>}
                </div>
                <div className="form-group mt-2">
                    <p>Username<span>*</span></p>
                    <input
                        className="form-control"
                        type="text"
                        value={username.Username}
                        name="Username"
                        onChange={handleUsernameChange}
                        required
                    />
                </div>
                <div className="form-group mt-2">
                    <p>Password<span>*</span></p>
                    <input
                        className="form-control"
                        type="password"
                        value={password.Password}
                        name="Password"
                        onChange={handlePasswordChange}
                        required
                    />
                </div>
                <div className="form-group mt-2">
                    <p>Confirm Password<span>*</span></p>
                    <input
                        className="form-control"
                        type="password"
                        value={confirmPassword.ConfirmPassword}
                        name="ConfirmPassword"
                        onChange={handleConfirmPasswordChange}
                        required
                    />
                </div>
                <div className="form-group mt-2">
                    <p>Role<span>*</span></p>
                    <input
                        className="form-control"
                        type="text"
                        value={role.Role}
                        name="Role"
                        onChange={handleRoleChange}
                        required
                    />
                </div>
                <div className="mt-2">
                    <button className="btn btn-primary" onClick={handleRegister}>Register</button>
                </div>
                <p className="mt-2">
                    Already have an account? <Link to="/Login">Login here</Link>
                </p>
            </div>
        </div>
    );
}

export default Register;
