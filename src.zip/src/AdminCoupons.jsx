import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import AdminHome from './AdminHome';

function AdminCoupons() {
    const [coupons, setCoupons] = useState([]);
    const [coupon, setCoupon] = useState({ couponCode: "", discountPercentage: 0, validFrom: "", validTill: "" });

    useEffect(() => {
        fetch("https://localhost:7012/api/Coupon")
            .then(result => result.json())
            .then(result => {
                setCoupons(result);
            });
    }, []);

    const deleteCoupon = (couponId) => {
        fetch('https://localhost:7012/api/Coupon/' + couponId, {
            method: 'DELETE',
        }).then(result => result.text()).then(result => {
            alert("Coupon deleted");
            setCoupons(coupons.filter(c => c.couponId !== couponId));
        });
    }

    const fetchAllCoupons = () => {
        fetch("https://localhost:7012/api/Coupon")
            .then(result => result.json())
            .then(result => {
                setCoupons(result);
            });
    };

    const addCoupon = () => {
        fetch("https://localhost:7012/api/Coupon", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(coupon)
        }).then(result => result.json()).then(result => {
            alert("Coupon added");
            fetchAllCoupons();
            setCoupon({ couponCode: "", discountPercentage: 0, validFrom: "", validTill: "" });
        });
    };

    return (
        <div className="container mt-4">
            <AdminHome />
            <h3>Coupon Form</h3>
            <form>
                <div className="mb-3">
                    <label htmlFor="couponCode" className="form-label">Coupon Code:</label>
                    <input type="text" className="form-control" id="couponCode" value={coupon.couponCode}
                        onChange={(e) => setCoupon(prev => ({ ...prev, couponCode: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label htmlFor="discountPercentage" className="form-label">Discount Percentage:</label>
                    <input type="number" className="form-control" id="discountPercentage" value={coupon.discountPercentage}
                        onChange={(e) => setCoupon(prev => ({ ...prev, discountPercentage: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label htmlFor="validFrom" className="form-label">Valid From:</label>
                    <input type="date" className="form-control" id="validFrom" value={coupon.validFrom}
                        onChange={(e) => setCoupon(prev => ({ ...prev, validFrom: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label htmlFor="validTill" className="form-label">Valid Till:</label>
                    <input type="date" className="form-control" id="validTill" value={coupon.validTill}
                        onChange={(e) => setCoupon(prev => ({ ...prev, validTill: e.target.value }))} />
                </div>
                <button type="button" className="btn btn-primary" onClick={fetchAllCoupons}>Show All Coupons</button>
                <button type="button" className="btn btn-success ms-2" onClick={addCoupon}>Add Coupon</button>
            </form>
            <h3 className="mt-4">List of Coupons</h3>
            <table className="table">
                <thead>
                    <tr>
                        <th>Coupon Code</th><th>Discount Percentage</th><th>Valid From</th><th>Valid Till</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {coupons.map(coupon => (
                        <tr key={coupon.couponId}>
                            <td>{coupon.couponCode}</td><td>{coupon.discountPercentage}</td><td>{coupon.validFrom}</td><td>{coupon.validTill}</td>
                            <td>
                                <button type="button" className="btn btn-danger" onClick={() => deleteCoupon(coupon.couponId)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AdminCoupons;