import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import test1 from './assets/LogoPng.png';

const ProductPage = () => {
    const { category } = useParams();
    const [products, setProducts] = useState([]);

    useEffect(() => {
        // Fetch product data based on the category when the component mounts
        getProductsByCategory(category);
    }, [category]);

    const getProductsByCategory = async (category) => {
        try {
            const response = await fetch(`https://localhost:7012/api/Product/productsByCategory/${category}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    //'Authorization': `Bearer ${token} `,
                },
            });

            if (!response.ok) {
                throw new Error('Failed to fetch products');
            }

            const productData = await response.json();
            setProducts(productData);
        } catch (error) {
            console.error('Error fetching products:', error.message);
        }
    };

    return (
        <div>
            <h2>Product List - {category}</h2>
            {/* ... (rest of your code for displaying products) */}
        </div>
    );
};

export default ProductPage;
