import React from 'react';
import Slider from './inc/Slider';
import Sofa from './assets/SofaCat.jpg';
import Bed from './assets/BedCat.jpg';
import Light from './assets/LightCap.jpg';
import Chair from './assets/Chair2Cat.jpg';
import Study from './assets/StudyCat.jpg';
import Dining from './assets/DiningCat.jpg';
import Coffee from './assets/CoffeeCap.jpg';
import Swing from './assets/SwingCat.jpg';
import Unit from './assets/UnitCat.jpg';
import Van from './assets/About1.jpg';
import Design from './assets/About2.jpg';

function Home() {
    return (
        <div>
            <div id="State">
                <Slider />
            </div>
            <section className="section">
                <div id="categories">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12 text-center">
                                <h3 className="main-heading">
                                    Explore Our Furniture Range
                                </h3>
                                <div className="underline"></div>
                            </div>
                        </div>
                    </div>

                    <div className="Categories">
                        <div className="container">
                            <div className="row">
                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Sofa} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Sofas</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Bed} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Beds</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Light} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Lighting</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Chair} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Seating</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Study} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Study Tables</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Dining} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Dining</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Coffee} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Coffee Tables</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Swing} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">Swing Chairs</p>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-4">
                                    <div className="card" style={{ width: '23rem' }}>
                                        <img className="card-img-top" src={Unit} alt="Card image cap" />
                                        <div className="card-body">
                                            <p className="card-text">TV Units</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <br /><br />
                    <div className="underline1"></div>
                </div>

                <div id="about">
                    <div className="containerSecret">
                        <div className="row">
                            <div className="col-md-12 text-center">
                                <h3 className="oursecret">
                                    Our Secret Sauce
                                </h3>
                                <div className="underline"></div>
                            </div>
                        </div>
                    </div>

                    <div className="row">
                        <div className="col-md-5">
                            <img className="align-self-center mr-3" src={Van} alt="Generic placeholder image" />
                        </div>
                        <div className="col-md-7">
                            <div className="media-body">
                                <p className="heading1">Our Best In Class <br />Big-Box Supply Chain</p>
                                <p className="body1">Indias furniture market used to be hyperlocal. FHSquare disrupted the very nature <br /> of this market by creating Indias largest big-box supply chain network. <br />FHSquareLogistics provides first-mile and last-mile logistics services to <br />buyers and sellers in over 500 cities. FHSquareLogistics has successfully delivered <br /> more than 10 million shipments in the last decade. After all, FHSquare is about <br /><b><i> Happy Furniture To You.</i></b></p>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div className="row">
                        <div className="col-md-6">
                            <div className="media-body">
                                <p className="heading2">Commercial Design &<br />Builder Services</p>
                                <p className="body2">Our team specializes in crafting designs that align with your brand identity, optimizing workspaces with quality furniture. Whether you're furnishing offices, restaurants, or other commercial spaces, our services cater to diverse needs. We prioritize a seamless blend of style and functionality to enhance the overall user experience.</p>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <img className="align-self-center mr-3" src={Design} alt="Generic placeholder image" />
                        </div>
                    </div>
                </div>

                

            </section>
        </div>
    );
}
export default Home;