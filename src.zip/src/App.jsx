import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './Layout';
import LoginComponent from './LoginComponent';
import Home from './Home';
import Footer from './Footer';
import ForgotPass from './ForgotPass';
import Register from './Register'; // Import the Register component
import Product from './Product';
import Cart from './Cart';
import AdminUser from './AdminUser';
import AdminCategories from './AdminCategories';
import AdminHome from './AdminHome';
import AdminProducts from './AdminProducts';
//import AdminWishLists from './AdminWishLists';
import AdminCoupons from './AdminCoupons';
// import Navbar from './Navbar';

function App() {
    const [isLoggedIn, setLoggedIn] = useState(false);
    const [username, setUserName] = useState("");
    const [userRole, setUserRole] = useState("");

    return (
        <div>
            <Layout isLoggedIn={isLoggedIn} setLoggedIn={setLoggedIn} username={username} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />
            <Routes>
                
                <Route path="/Login" element={<LoginComponent isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/AdminUser" element={<AdminUser isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/AdminCoupons" element={<AdminCoupons isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />

                <Route path="/AdminProducts" element={<AdminProducts isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/AdminHome" element={<AdminHome isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/AdminCategories" element={<AdminCategories isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/Home" element={<Home isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/Product" element={<Product isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/Cart" element={<Cart isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/ForgotPass" element={<ForgotPass isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} setUserRole={setUserRole} userRole={userRole} />} />
                <Route path="/Register" element={<Register />} /> {/* Route for the Register component */}
                <Route path="/" element={<Navigate to="/Home" />} />
            </Routes>
            <Footer />
        </div>
    );
}

export default App;
