import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import AdminHome from './AdminHome';

function User() {
    const [users, setUsers] = useState([]);
    const [user, setUser] = useState({ userName: "", password: "", role: "" });

    useEffect(() => {
        fetch("https://localhost:7012/api/User")
            .then(result => result.json())
            .then(result => {
                setUsers(result);
            });
    }, []);

    const deleteUser = (userName) => {
        fetch('https://localhost:7012/api/User/' + userName, {
            method: 'DELETE',
        }).then(result => result.text()).then(result => {
            alert("User deleted");
            setUsers(users.filter(u => u.userName !== userName));
        });
    }

    const fetchAllUsers = () => {
        fetch("https://localhost:7012/api/User")
            .then(result => result.json())
            .then(result => {
                setUsers(result);
            });
    };

    const addUser = () => {
        fetch("https://localhost:7012/api/User", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(user)
        }).then(result => result.json())
            .then(result => {
                alert("User added");
                setUsers([...users, result]);
                setUser({ userName: "", password: "", role: "" });
            });
    };

    const updateUser = (userName) => {
        fetch('https://localhost:7012/api/User/' + userName, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(user)
        }).then(result => result.json())
            .then(result => {
                alert("User updated");
                setUsers(users.map(u => u.userName === userName ? result : u));
                setUser({ userName: "", password: "", role: "" });
            });
    };

    const showUserByUsername = (userName) => {
        fetch('https://localhost:7012/api/User/' + userName)
            .then(result => result.json())
            .then(result => {
                alert(`Username: ${result.userName}\nPassword: ${result.password}\nRole: ${result.role}`);
            });
    };

    return (
        <div className="container mt-4">
            <AdminHome />
            <h3>User Form</h3>
            <form>
                <div className="mb-3">
                    <label htmlFor="userName" className="form-label">UserName:</label>
                    <input type="text" className="form-control" id="userName" value={user.userName}
                        onChange={(e) => setUser(prev => ({ ...prev, userName: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label htmlFor="password" className="form-label">Password:</label>
                    <input type="password" className="form-control" id="password" value={user.password}
                        onChange={(e) => setUser(prev => ({ ...prev, password: e.target.value }))} />
                </div>
                <div className="mb-3">
                    <label htmlFor="role" className="form-label">Role:</label>
                    <input type="text" className="form-control" id="role" value={user.role}
                        onChange={(e) => setUser(prev => ({ ...prev, role: e.target.value }))} />
                </div>
                <button type="button" className="btn btn-primary" onClick={fetchAllUsers}>Show All Users</button>
                <button type="button" className="btn btn-success ms-2" onClick={addUser}>Add User</button>
                <button type="button" className="btn btn-warning ms-2" onClick={() => updateUser(user.userName)}>Update User</button>
                <button type="button" className="btn btn-info ms-2" onClick={() => showUserByUsername(user.userName)}>Show Single User</button>
            </form>
            <h3 className="mt-4">List of Users</h3>
            <table className="table">
                <thead>
                    <tr>
                        <th>UserName</th><th>Password</th><th>Role</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map(user => (
                        <tr key={user.userName}>
                            <td>{user.userName}</td><td>{user.password}</td><td>{user.role}</td>
                            <td>
                                <button type="button" className="btn btn-danger" onClick={() => deleteUser(user.userName)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default User;