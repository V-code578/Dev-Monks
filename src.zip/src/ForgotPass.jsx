import React, { useState } from 'react';

function ForgotPass() {
    const [userName, setUserName] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [authenticationError, setAuthenticationError] = useState('');

    const handleUserNameChange = (event) => {
        const value = event.target.value;
        setUserName(value);
    };

    const handleNewPasswordChange = (event) => {
        const value = event.target.value;
        setNewPassword(value);
    };

    const updateUser = async () => {
        const user = {
            UserName: userName,
            Password: newPassword
        };

        try {
            const response = await fetch(`https://localhost:7012/api/user/${userName}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(user),
            });

            if (response.ok) {
                setAuthenticationError('');
                console.log('Password reset successful.');
            } else {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Password reset failed. Please try again later.');
            }
        } catch (error) {
            console.error('Password reset error:', error);
            setAuthenticationError(error.message || 'Password reset failed. Please try again later.');
        }
    };

    const handleResetPassword = async () => {
        await updateUser();
    };

    return (
        <div className="container">
            <div className="w-50 mt-5 mx-auto">
                <h2>Forgot Password</h2>
                <div className="form-group mt-2">
                    <p>User Name</p>
                    <input
                        className="form-control"
                        type="text"
                        value={userName}
                        name="UserName"
                        onChange={handleUserNameChange}
                        required
                    />
                </div>
                <div className="form-group mt-2">
                    <p>New Password</p>
                    <input
                        className="form-control"
                        type="password"
                        value={newPassword}
                        name="NewPassword"
                        onChange={handleNewPasswordChange}
                        required
                    />
                </div>
                <div className="mt-2">
                    <button className="btn btn-primary" onClick={handleResetPassword}>
                        Reset Password
                    </button>
                </div>
                {authenticationError && <p className="mt-2">{authenticationError}</p>}
            </div>
        </div>
    );
}

export default ForgotPass;