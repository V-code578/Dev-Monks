import React from 'react';
import Logo from '../Assets/LogoPng.png';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';


//Before The User or Admin Login. This Navbar is initiated to Render.

function NavbarAfter() {
    return (
        <>
            <nav id="navbar-example2" className="navbar navbar bg-light">
                <a className="navbar-brand" href="#State"><img src={Logo} className="logo" alt="..." /></a>
                <ul className="nav nav-pills">
                    <li>
                        <Link to="/home" className="nav-link">Home</Link>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#categories">Categories</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#about">About Us</a>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href="#footer">Contact Us</a>
                    </li>
                    <li>
                        <a className="nav-link" href="/login">Login</a>
                    </li>
                    <li>
                        <Link to="/register" className="nav-link">Register</Link>
                    </li>
                </ul>
            </nav>
        </>
    );
}

export default NavbarAfter;
