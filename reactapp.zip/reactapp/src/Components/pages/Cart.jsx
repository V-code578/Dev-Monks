import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from 'react-bootstrap';

//This function is rendered once the User clicks on the AddToCart or AddToWishList.
function Cart(props) {
    const [carts, setCarts] = useState([]);
    const navigate = useNavigate();
    const [products, setProducts] = useState([]);

    //This function fetches the data present in the cart table for the particular UserName
    useEffect(() => {
        const fetchCartData = async () => {
            try {
                const response = await fetch(`https://localhost:7012/api/Cart/CartByUserName/${props.username}`);
                if (!response.ok) {
                    throw new Error('Failed to fetch cart data');
                }
                const cartData = await response.json();
                setCarts(cartData);
                const productIds = cartData.map((cart) => cart.productId);
                const productResponses = await Promise.all(
                    productIds.map((productId) =>
                        fetch(`https://localhost:7012/api/Product/ProductById/${productId}`)
                    )
                );
                const productData = await Promise.all(productResponses.map((response) => response.json()));
                setProducts(productData);
            } catch (error) {
                console.error('Error fetching cart data:', error.message);
            }
        };

        fetchCartData();
    }, [props.username]);

    //This function removes the particular product from the Cart
    const removeFromCart = async (productId) => {
        try {
            const response = await fetch('http://localhost:7012/api/cart/', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ productId }),
            });

            if (!response.ok) {
                throw new Error('Failed to remove from cart');
            }

            // Refresh cart data after removing
            const updatedCartData = carts.filter((cart) => cart.productId !== productId);
            setCarts(updatedCartData);
        } catch (error) {
            console.error('Error removing from cart:', error.message);
        }
    };


    const clearCart = async () => {
        try {
            const response = await fetch('http://localhost:7012/api/cart/Clear', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to clear cart');
            }

            // Clear cart data
            setCarts([]);
        } catch (error) {
            console.error('Error clearing cart:', error.message);
        }
    };

    const handleBuyNow = async () => {
        try {
            // Call your server-side endpoint to handle the purchase logic
            const response = await fetch('https://localhost:7012/api/Order/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Failed to complete the purchase');
            }

            navigate('/order');
            console.log('Purchase successful!');
        } catch (error) {
            console.error('Error during purchase:', error.message);
        }
    };

    return (
        <div>
            <div>
                <h2 className="main-heading">Your Cart</h2>
                <div className="underline"></div> <br />

                {carts.length > 0 ? (
                    <>
                        <ul>
                            {carts.map((cart, index) => (
                                <li key={cart.productId}>
                                    <strong>Product Name:</strong> {products[index]?.productName}
                                    <br />
                                    <strong>Price:</strong> {products[index]?.price}
                                    <br />
                                    <strong>Description:</strong> {products[index]?.description}
                                    <br />
                                    <Button onClick={() => removeFromCart(cart.productId)}>Remove</Button>
                                </li>
                            ))}
                        </ul>

                        <Button onClick={clearCart}>Clear Cart</Button>
                        <Button onClick={handleBuyNow}>Buy Now</Button>
                    </>
                ) : (
                    <p>Your cart is empty.</p>
                )}
            </div>
        </div>
    );
}

export default Cart;

