import React, { useState, useEffect} from 'react';

import Bed1 from '../Assets/Beds/Bed1.jpg';
import Bed2 from '../Assets/Beds/Bed2.jpg';
import Bed3 from '../Assets/Beds/Bed3.jpg';
import Bed4 from '../Assets/Beds/Bed4.jpg';
import Bed5 from '../Assets/Beds/Bed5.jpg';
import Bed6 from '../Assets/Beds/Bed6.jpg';
import Bed7 from '../Assets/Beds/Bed7.jpg';



const ProductList = ({ products, addToCart, addToWishlist }) => {
    const bedImages = [Bed1, Bed2, Bed3, Bed4, Bed5, Bed6, Bed7];

    const shuffleArray = (array) => {
        const shuffledArray = array.slice(); // Copy the array to avoid mutating the original
        for (let i = shuffledArray.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffledArray[i], shuffledArray[j]] = [shuffledArray[j], shuffledArray[i]];
        }
        return shuffledArray;
    };

    const [shuffledBedImages, setShuffledBedImages] = useState([]);

    useEffect(() => {
        setShuffledBedImages(shuffleArray(bedImages));
    }, [products]);

    const renderProductImage = (productName) => {
        const lowerProductName = productName.toLowerCase();
        let image;

        if (lowerProductName.includes('bed')) {
            const imageIndex = Math.floor(Math.random() * shuffledBedImages.length);
            image = shuffledBedImages[imageIndex];
        }
        return <img src={image} className="img-fluid rounded-start" alt={productName} />
    };
    return (
        <div>
            <br />
            <h1 className="main-heading">Bed's</h1>
            <div className="underline"></div> <br />
            <ul style={{ listStyleType: 'none', padding: 0 }} className="products">
                {products.map((product) => (
                    <li key={product.productId}>
                        <div className="card mb-12" style={{ width: '1050px' }}>
                            <div className="row g-0">
                                <div className="col-md-7">
                                    {renderProductImage(product.productName)}
                                </div>
                                <div className="col-md-5">
                                    <div className="card-body">
                                        <h2 class="text-center" className="card-title">{product.productName}</h2>
                                        <h3 class="text-center" className="card-text">{product.description}</h3>
                                        <br />
                                        <h4 >Price: <b>Rs.{product.price.toFixed(2)} </b></h4>
                                        <button class="button-style" onClick={() => addToCart(product.productId)} >Add to Cart</button>{' '}
                                        <button class="button-style" onClick={() => addToWishlist(product.productId)} >Add to Wishlist</button>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};



function CatBed() {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        fetch("https://localhost:7012/api/Product/ProductByCategory/2")
            .then((response) => response.json())
            .then((data) => {
                setProducts(data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);

    const redirectToLogin = () => {
        navigate('/login');
    };

    const isUserLoggedIn = () => {
        const user = localStorage.getItem('user');
        return !!user;
    };

    const addToCart = (productId) => {
        if (!isUserLoggedIn()) {
            redirectToLogin();
            return;
        }

        const selectedProduct = products.find((product) => product.productId === productId);
        setCart(selectedProduct);
        navigate('/categories'); //cart
    };

    const addToWishlist = (productId) => {
        if (!isUserLoggedIn()) {
            redirectToLogin();
            return;
        }

        const selectedProduct = products.find((product) => product.productId === productId);
        setWishlist(selectedProduct);

        navigate('/categories'); //wishlist
    };

    return (
        <div>
            <ProductList products={products} addToCart={addToCart} addToWishlist={addToWishlist} />
        </div>
    );
}
export default CatBed;