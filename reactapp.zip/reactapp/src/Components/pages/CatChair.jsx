import React, { useState, useEffect } from 'react';

import Chair1 from '../Assets/Seating/Chair1.jpg';
import Chair2 from '../Assets/Seating/Chair2.jpg';
import Chair3 from '../Assets/Seating/Chair3.jpg';
import Chair4 from '../Assets/Seating/Chair4.jpg';
import Chair5 from '../Assets/Seating/Chair5.jpg';
import Chair6 from '../Assets/Seating/Chair6.jpg';
import Chair7 from '../Assets/Seating/Chair7.jpg';
import Chair8 from '../Assets/Seating/Chair8.jpg';
import Chair9 from '../Assets/Seating/Chair9.jpg';
import Chair10 from '../Assets/Seating/Chair10.jpg';


const ProductList = ({ products, addToCart, addToWishlist }) => {
    const chairImages = [Chair1, Chair2, Chair3, Chair4, Chair5, Chair6, Chair7, Chair8, Chair9, Chair10];

    const shuffleArray = (array) => {
        const shuffledArray = array.slice(); // Copy the array to avoid mutating the original
        for (let i = shuffledArray.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffledArray[i], shuffledArray[j]] = [shuffledArray[j], shuffledArray[i]];
        }
        return shuffledArray;
    };

    const [shuffledChairImages, setShuffledChairImages] = useState([]);

    useEffect(() => {
        setShuffledChairImages(shuffleArray(chairImages));
    }, [products]);

    const renderProductImage = (productName) => {
        const lowerProductName = productName.toLowerCase();
        let image;

        if (lowerProductName.includes('chair')) {
            const imageIndex = Math.floor(Math.random() * shuffledChairImages.length);
            image = shuffledChairImages[imageIndex];
        }
        return <img src={image} className="img-fluid rounded-start" alt={productName} />
    };
    return (
        <div>
            <br />
            <h1 className="main-heading">Chairs</h1>
            <div className="underline"></div> <br />
            <ul style={{ listStyleType: 'none', padding: 0 }} className="products">
                {products.map((product) => (
                    <li key={product.productId}>
                        <div className="card mb-12" style={{ width: '1050px' }}>
                            <div className="row g-0">
                                <div className="col-md-7">
                                    {renderProductImage(product.productName)}
                                </div>
                                <div className="col-md-5">
                                    <div className="card-body">
                                        <h2 class="text-center" className="card-title">{product.productName}</h2>
                                        <h3 class="text-center" className="card-text">{product.description}</h3>
                                        <br />
                                        <h4 >Price: <b>Rs.{product.price.toFixed(2)} </b></h4>
                                        <button class="button-style" onClick={() => addToCart(product.productId)} >Add to Cart</button>{' '}
                                        <button class="button-style" onClick={() => addToWishlist(product.productId)} >Add to Wishlist</button>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};



function CatChair() {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        fetch("https://localhost:7012/api/Product/ProductByCategory/4")
            .then((response) => response.json())
            .then((data) => {
                setProducts(data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);

    const redirectToLogin = () => {
        navigate('/login');
    };

    const isUserLoggedIn = () => {
        const user = localStorage.getItem('user');
        return !!user;
    };

    const addToCart = (productId) => {
        if (!isUserLoggedIn()) {
            redirectToLogin();
            return;
        }

        const selectedProduct = products.find((product) => product.productId === productId);
        setCart(selectedProduct);
        navigate('/categories'); //cart
    };

    const addToWishlist = (productId) => {
        if (!isUserLoggedIn()) {
            redirectToLogin();
            return;
        }

        const selectedProduct = products.find((product) => product.productId === productId);
        setWishlist(selectedProduct);

        navigate('/categories'); //wishlist
    };

    return (
        <div>
            <ProductList products={products} addToCart={addToCart} addToWishlist={addToWishlist} />
        </div>
    );

}
export default CatChair;