import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function Register() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [role, setRole] = useState('');
    const [registrationError, setRegistrationError] = useState('');

    const handleUsernameChange = (event) => {
        setUsername(event.target.value);
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleConfirmPasswordChange = (event) => {
        setConfirmPassword(event.target.value);
    };

    const handleRoleChange = (event) => {
        setRole(event.target.value);
    };

    const handleRegister = async () => {
        // Validation logic
        const emailRegex = /^[A-Za-z0-9._%+-]+@[a-z]+\.[a-z]{2,}$/;

        if (username === "") {
            setRegistrationError('Username is required');
            return;
        }
        if (!emailRegex.test(username)) {
            setRegistrationError('Invalid Email Format (Should be, for example: example@gmail.com)');
            return;
        }
        if (password === "") {
            setRegistrationError('Password is required');
            return;
        }
        if (password.length < 8) {
            setRegistrationError('Password should be a minimum of 8 characters');
            return;
        }
        if (role === "") {
            setRegistrationError('Role is required');
            return;
        }

        const rolereg = /^[UA]+$/;
        if (!rolereg.test(role)) {
            setRegistrationError('Role must be U or A');
            return;
        }

        if (!username || !password || !confirmPassword || !role) {
            setRegistrationError('All fields are required');
            return;
        }

        if (password !== confirmPassword) {
            setRegistrationError('Password and Confirm Password must match');
            return;
        }

        // Call the registration API
        try {
            const user = {
                UserName: username,
                Password: password,
                Role: role
            };

            console.log('Registration data:', user);

            const response = await fetch('https://localhost:7012/api/User/', {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(user)
            });

            console.log('Registration response:', response);

            if (response.status === 201) {
                alert('Registration successful!');
            } else {
                throw new Error(`Registration failed with status ${response.status}`);
            }
        } catch (error) {
            console.error('Registration error:', error);
            setRegistrationError('Registration failed. Please try again later.');
        }
    };

    return (
        <div className="container">
            <div className="w-50 mt-5 mx-auto">
                <h2>Register</h2>
                <div className="errors">
                    <p className="text-danger">Fields marked with * are mandatory</p>
                    {registrationError !== '' && <li className="text-danger">{registrationError}</li>}
                </div>
                <div className="form-group mt-2">
                    <p>Username<span className="text-danger">*</span></p>
                    <input
                        className="form-control"
                        type="text"
                        value={username}
                        name="Username"
                        onChange={handleUsernameChange}
                        required
                    />
                </div>
                <div className="form-group mt-2">
                    <p>Password<span className="text-danger">*</span></p>
                    <input
                        className="form-control"
                        type="password"
                        value={password}
                        name="Password"
                        onChange={handlePasswordChange}
                        required
                    />
                </div>
                <div className="form-group mt-2">
                    <p>Confirm Password<span className="text-danger">*</span></p>
                    <input
                        className="form-control"
                        type="password"
                        value={confirmPassword}
                        name="ConfirmPassword"
                        onChange={handleConfirmPasswordChange}
                        required
                    />
                </div>
                <div className="form-group mt-2">
                    <p>Role<span className="text-danger">*</span></p>
                    <input
                        className="form-control"
                        type="text"
                        value={role}
                        name="Role"
                        onChange={handleRoleChange}
                        required
                    />
                </div>
                <div className="mt-2">
                    <button className="btn btn-primary" onClick={handleRegister}>Register</button>
                </div>
                <p className="mt-2">
                    Already have an account? <Link to="/Login">Login here</Link>
                </p>
            </div>
        </div>
    );
}

export default Register;