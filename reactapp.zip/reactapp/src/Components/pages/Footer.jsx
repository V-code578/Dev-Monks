import React from 'react';

function Footer() {
    return (
        <></>
    );
}
export default Footer;