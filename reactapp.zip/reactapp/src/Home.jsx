import React from 'react';
import { Carousel } from 'react-bootstrap'; // Import Carousel from react-bootstrap
import SearchBar from './SearchBar';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import Footer from './Footer';

const Home = () => {
    const handleSearch = (searchTerm) => {
        // Implement your search logic here
        console.log('Searching for:', searchTerm);
        // You can update the component state or make an API call, etc.
    };

    return (
        <div style={{ width: '100%', overflowX: 'hidden' }}>
            <SearchBar onSearch={handleSearch} />

            <Carousel>
                {/* Add Carousel slides here */}
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="https://images.pexels.com/photos/2360673/pexels-photo-2360673.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                        alt="First slide" width="100%" height="450"
                    />
                </Carousel.Item>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="https://images.pexels.com/photos/2510067/pexels-photo-2510067.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                        alt="Second slide" width="100%" height="450" />
                </Carousel.Item>
                <Carousel.Item>
                    <img
                        className="d-block w-100"
                        src="https://images.pexels.com/photos/276724/pexels-photo-276724.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                        alt="Third slide" width="100%" height="450" />
                </Carousel.Item>
            </Carousel>

            {/* Add more content */}
            
        </div>
    );
};

export default Home;
