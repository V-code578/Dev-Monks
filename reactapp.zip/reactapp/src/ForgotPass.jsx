import React, { useState } from 'react';

function ForgotPass() {
    const [email, setEmail] = useState('');
    const [authenticationError, setAuthenticationError] = useState('');

    const handleEmailChange = (event) => {
        const value = event.target.value;
        setEmail(value);
    };

    const handleResetPassword = async () => {
        const user = {
            UserName: email
            // Include any other necessary information for the password reset process
        };

        try {
            const response = await fetch('https://localhost:7012/api/User/', {
                method: 'put',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                },
                body: JSON.stringify(user),
            });

            if (response.status === 200) {
                // Password reset initiated successfully
                setAuthenticationError('');
                console.log('Password reset initiated successfully.');
            } else if (response.status === 404) {
                // User not found
                setAuthenticationError('User not found. Please check your email address.');
            } else {
                const contentType = response.headers.get('content-type');
                if (contentType && contentType.includes('application/json')) {
                    const errorData = await response.json(); // Get error details from the response
                    throw new Error(`Password reset failed: ${errorData.message}`);
                } else {
                    throw new Error('Password reset failed. Unexpected response from the server.');
                }
            }
        } catch (error) {
            console.error('Password reset error:', error);
            setAuthenticationError(error.message || 'Password reset failed. Please try again later.');
        }
    };

    return (
        <div className="container">
            <div className="w-50 mt-5 mx-auto">
                <h2>Forgot Password</h2>
                <div className="form-group mt-2">
                    <p>Email Address</p>
                    <input
                        className="form-control"
                        type="email"
                        value={email}
                        name="Email"
                        onChange={handleEmailChange}
                        required
                    />
                </div>
                <div className="mt-2">
                    <button className="btn btn-primary" onClick={handleResetPassword}>
                        Reset Password
                    </button>
                </div>
                {authenticationError && <p className="mt-2">{authenticationError}</p>}
            </div>
        </div>
    );
}

export default ForgotPass;
