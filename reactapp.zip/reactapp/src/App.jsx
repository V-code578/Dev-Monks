import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './Layout';
import LoginComponent from './LoginComponent';
import Home from './Home';
import Footer from './Footer';
import ForgotPass from './ForgotPass';
import Register from './Register'; // Import the Register component

function App() {
    const [isLoggedIn, setLoggedIn] = useState(false);
    const [username, setUserName] = useState(0);

    return (
        <div>
            <Layout isLoggedIn={isLoggedIn} setLoggedIn={setLoggedIn} />
            <Routes>
                <Route path="/Login" element={<LoginComponent isLoggedIn={isLoggedIn} username={username} setLoggedIn={setLoggedIn} setUserName={setUserName} />} />
                <Route path="/Home" element={<Home />} />
                <Route path="/ForgotPass" element={<ForgotPass />} />
                <Route path="/Register" element={<Register />} /> {/* Route for the Register component */}
                <Route path="/" element={<Navigate to="/Home" />} />
            </Routes>
            <Footer />
        </div>
    );
}

export default App;
