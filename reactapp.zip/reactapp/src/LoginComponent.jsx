import { useState, useEffect } from 'react';
import './App.css';
import { useNavigate, Link } from "react-router-dom";
//import ForgotPass from './ForgotPass';


function LoginComponent(props) {
    const [email, setEmail] = useState({ Email: "", error: "" });
    const [password, setPassword] = useState({ Password: "", error: "" });
    const [role, setRole] = useState({ Role: "", error: "" });
    const [authenticationError, setError] = useState("");
    const [users, setUsers] = useState({});
    const navigate = useNavigate();


    const handleEmailChange = (event) => {
        const value = event.target.value;
        if (value == "") {
            setEmail({ Email: "", error: "Email is Required" })
        }
        else {
            setEmail({ Email: value, error: "" })
        }
    }

    const handlePasswordChange = (event) => {
        const value = event.target.value;
        if (value == "") {
            setPassword({ Password: "", error: "Password is Required" })
        }
        else {
            setPassword({ Password: value, error: "" })
        }
    }
    const handleRole = (event) => {
        const value = event.target.value;
        if (value == "") {
            setRole({ Role: "", error: "Role is Required" })
        }
        else {
            setRole({ Role: value, error: "" })
        }
    }

    async function handleLogin() {
        const user = {
            UserName: email.Email,
            Password: password.Password,
            Role: role.Role
        }
        await fetch("https://localhost:7012/api/User/login/", {
            method: "post",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(user),
        }
        ).then((response) => {
            //alert(response.status);
            if (response.status == 400) {
                throw new Error();
            }
            if (response.status == 401) {
                setError("Invalid Username Or Password");
            }
            return response.json();
        }).then((result) => props.setUserName(result.UserName))
            .then(() => {
                props.setLoggedIn(true);
                navigate('/Home');
            });
    }


    return (
        <div className='container'>
            <div className='w-50 mt-5 mx-auto'>
                <h2>LOGIN</h2>
                <div className='errors'>
                    <p>Fields marked with * are mandatory</p>
                    {email.error !== "" && <li>{email.error}</li>}
                    {password.error !== "" && <li>{password.error}</li>}
                    {authenticationError !== "" && <li>{authenticationError}</li>}
                </div>
                <div className='form-group mt-2'>
                    <p>Email Address<span>*</span></p>
                    <input className='form-control' type="email" value={email.Email} name='Email' onChange={handleEmailChange} required />
                </div>
                <div className='form-group mt-2'>
                    <p>Password<span>*</span></p>
                    <input className='form-control' type="password" value={password.Password} name='Password' onChange={handlePasswordChange} required />
                </div>
                <div className='form-group mt-2'>
                    <p>Role<span>*</span></p>
                    <input className='form-control' type="role" value={role.Role} name='Role' onChange={handleRole} required />
                </div>
                <div className='mt-2'>
                    <button className='btn btn-primary' onClick={handleLogin} >Submit</button>
                </div>
                {/* Link to the ForgotPass component */}
                <p className="mt-2">
                    <Link to="/ForgotPass">Forgot Password?</Link>
                </p>
            </div>
        </div>
    );
}

export default LoginComponent;