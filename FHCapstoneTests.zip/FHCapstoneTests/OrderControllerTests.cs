﻿using FHSquareLibrary.Models;
using FHSquareLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using webapi.Controllers;

namespace webapi.tests
{
    [TestFixture]
    public class OrderControllerTests
    {
        private Mock<IOrderRepo> mockOrderRepo;
        private OrderController orderController;

        [SetUp]
        public void Setup()
        {
            mockOrderRepo = new Mock<IOrderRepo>();
            orderController = new OrderController(mockOrderRepo.Object);
        }

        [Test]
        public async Task GetByUserName_WithValidUserName_ReturnsOkResultWithListOfOrders()
        {
            // Arrange
            string userName = "testUser";
            List<Order> expectedOrders = new List<Order>()
            {
                new Order { OrderId = 1, UserName = userName },
                new Order { OrderId = 2, UserName = userName }
            };
            mockOrderRepo.Setup(repo => repo.GetOrdersByUserName(userName)).ReturnsAsync(expectedOrders);

            // Act
            ActionResult result = await orderController.GetByUserName(userName);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            OkObjectResult okResult = (OkObjectResult)result;
            Assert.AreEqual(expectedOrders, okResult.Value);
        }

        [Test]
        public async Task GetByUserName_WithInvalidUserName_ReturnsNotFoundResult()
        {
            // Arrange
            string userName = "nonExistingUser";
            string errorMessage = "No orders found for the specified user.";
            mockOrderRepo.Setup(repo => repo.GetOrdersByUserName(userName)).ThrowsAsync(new Exception(errorMessage));

            // Act
            ActionResult result = await orderController.GetByUserName(userName);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            NotFoundObjectResult notFoundResult = (NotFoundObjectResult)result;
            Assert.AreEqual(errorMessage, notFoundResult.Value);
        }

        [Test]
        public async Task GetById_WithValidOrderId_ReturnsOkResultWithOrder()
        {
            // Arrange
            int orderId = 1;
            Order expectedOrder = new Order { OrderId = orderId, UserName = "testUser" };
            mockOrderRepo.Setup(repo => repo.GetOrderById(orderId)).ReturnsAsync(expectedOrder);

            // Act
            ActionResult result = await orderController.GetById(orderId);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            OkObjectResult okResult = (OkObjectResult)result;
            Assert.AreEqual(expectedOrder, okResult.Value);
        }

        [Test]
        public async Task GetById_WithInvalidOrderId_ReturnsNotFoundResult()
        {
            // Arrange
            int orderId = 1;
            string errorMessage = "Order not found.";
            mockOrderRepo.Setup(repo => repo.GetOrderById(orderId)).ThrowsAsync(new Exception(errorMessage));

            // Act
            ActionResult result = await orderController.GetById(orderId);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            NotFoundObjectResult notFoundResult = (NotFoundObjectResult)result;
            Assert.AreEqual(errorMessage, notFoundResult.Value);
        }

        [Test]
        public async Task Insert_ReturnsCreatedResultWithInsertedOrder()
        {
            // Arrange
            Order orderToInsert = new Order { OrderId = 1, UserName = "testUser" };
            mockOrderRepo.Setup(repo => repo.AddOrder(orderToInsert)).Returns(Task.CompletedTask);

            // Act
            ActionResult result = await orderController.Insert(orderToInsert);

            // Assert
            Assert.IsInstanceOf<CreatedResult>(result);
            CreatedResult createdResult = (CreatedResult)result;
            Assert.AreEqual($"api/order/{orderToInsert.OrderId}", createdResult.Location);
            Assert.AreEqual(orderToInsert, createdResult.Value);
        }

        [Test]
        public async Task Update_ReturnsOkResultWithUpdatedOrder()
        {
            // Arrange
            int orderId = 1;
            Order orderToUpdate = new Order { OrderId = orderId, UserName = "testUser" };
            mockOrderRepo.Setup(repo => repo.UpdateOrder(orderId, orderToUpdate)).Returns(Task.CompletedTask);

            // Act
            ActionResult result = await orderController.Update(orderId, orderToUpdate);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            OkObjectResult okResult = (OkObjectResult)result;
            Assert.AreEqual(orderToUpdate, okResult.Value);
        }

        [Test]
        public async Task Delete_ReturnsOkResult()
        {
            // Arrange
            int orderId = 1;
            mockOrderRepo.Setup(repo => repo.CancelOrder(orderId)).Returns(Task.CompletedTask);

            // Act
            ActionResult result = await orderController.Delete(orderId);

            // Assert
            Assert.IsInstanceOf<OkResult>(result);
        }
    }
}