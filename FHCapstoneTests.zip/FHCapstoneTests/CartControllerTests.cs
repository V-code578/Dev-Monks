﻿using FHSquareLibrary.Models;
using FHSquareLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using webapi.Controllers;

namespace FHCapstoneTests
{
    [TestFixture]
    public class CartControllerTests
    {
        private CartController _controller;
        private Mock<ICartRepo> _cartRepoMock;

        [SetUp]
        public void Setup()
        {
            _cartRepoMock = new Mock<ICartRepo>();
            _controller = new CartController(_cartRepoMock.Object);
        }

        [Test]
        public async Task GetByUserName_WithValidUserName_ReturnsListOfCarts()
        {
            // Arrange
            var userName = "JohnDoe";
            var carts = new List<Cart>
        {
            new Cart { UserName = userName, ProductId = 1 },
            new Cart { UserName = userName, ProductId = 2 }
        };
            _cartRepoMock.Setup(repo => repo.GetCartByUserName(userName)).ReturnsAsync(carts);

            // Act
            var result = await _controller.GetByUserName(userName);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(carts, okResult.Value);
        }

        [Test]
        public async Task GetByUserName_WithInvalidUserName_ReturnsNotFound()
        {
            // Arrange
            var userName = "JohnDoe";
            _cartRepoMock.Setup(repo => repo.GetCartByUserName(userName)).ThrowsAsync(new Exception("Cart not found"));

            // Act
            var result = await _controller.GetByUserName(userName);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            var notFoundResult = result as NotFoundObjectResult;
            Assert.AreEqual("Cart not found", notFoundResult.Value);
        }

        [Test]
        public async Task GetByUserNameAndProductId_WithValidUserNameAndProductId_ReturnsCart()
        {
            // Arrange
            var userName = "JohnDoe";
            var productId = 1;
            var cart = new Cart { UserName = userName, ProductId = productId };
            _cartRepoMock.Setup(repo => repo.GetCartByUserNameAndProductId(userName, productId)).ReturnsAsync(cart);

            // Act
            var result = await _controller.GetByUserNameAndProductId(userName, productId);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(cart, okResult.Value);
        }

        [Test]
        public async Task GetByUserNameAndProductId_WithInvalidUserNameAndProductId_ReturnsNotFound()
        {
            // Arrange
            var userName = "JohnDoe";
            var productId = 1;
            _cartRepoMock.Setup(repo => repo.GetCartByUserNameAndProductId(userName, productId)).ThrowsAsync(new Exception("Cart not found"));

            // Act
            var result = await _controller.GetByUserNameAndProductId(userName, productId);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            var notFoundResult = result as NotFoundObjectResult;
            Assert.AreEqual("Cart not found", notFoundResult.Value);
        }

        [Test]
        public async Task GetAll_WithValidRequest_ReturnsListOfCarts()
        {
            // Arrange
            var carts = new List<Cart>
        {
            new Cart { UserName = "JohnDoe", ProductId = 1 },
            new Cart { UserName = "JaneSmith", ProductId = 2 }
        };
            _cartRepoMock.Setup(repo => repo.GetAllCarts()).ReturnsAsync(carts);

            // Act
            var result = await _controller.GetAll();

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(carts, okResult.Value);
        }

        [Test]
        public async Task GetAll_WithInvalidRequest_ReturnsNotFound()
        {
            // Arrange
            _cartRepoMock.Setup(repo => repo.GetAllCarts()).ThrowsAsync(new Exception("Carts not found"));

            // Act
            var result = await _controller.GetAll();

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            var notFoundResult = result as NotFoundObjectResult;
            Assert.AreEqual("Carts not found", notFoundResult.Value);
        }

        [Test]
        public async Task Add_WithValidCart_ReturnsCreatedResultWithCart()
        {
            // Arrange
            var cart = new Cart { UserName = "JohnDoe", ProductId = 1 };

            // Act
            var result = await _controller.Add(cart);

            // Assert
            Assert.IsInstanceOf<CreatedResult>(result);
            var createdResult = result as CreatedResult;
            Assert.AreEqual($"api/cart/{cart.UserName}", createdResult.Location);
            Assert.AreEqual(cart, createdResult.Value);
        }

        [Test]
        public async Task Update_WithValidUserNameAndProductId_ReturnsOkResult()
        {
            // Arrange
            var userName = "JohnDoe";
            var productId = 1;
            var cart = new Cart { UserName = userName, ProductId = productId };

            // Act
            var result = await _controller.Update(userName, productId, cart);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(cart, okResult.Value);
        }

        [Test]
        public async Task Remove_WithValidUserNameAndProductId_ReturnsOkResult()
        {
            // Arrange
            var userName = "JohnDoe";
            var productId = 1;

            // Act
            var result = await _controller.Remove(userName, productId);

            // Assert
            Assert.IsInstanceOf<OkResult>(result);
        }

        [Test]
        public async Task Clear_WithValidUserName_ReturnsOkResult()
        {
            // Arrange
            var userName = "JohnDoe";

            // Act
            var result = await _controller.Clear(userName);

            // Assert
            Assert.IsInstanceOf<OkResult>(result);
        }
    }
}
