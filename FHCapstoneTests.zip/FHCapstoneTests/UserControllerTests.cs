﻿using NUnit.Framework;
using Moq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using webapi.Controllers;
using FHSquareLibrary.Models;
using FHSquareLibrary.Repos;

namespace FHCapstoneTests
{
    [TestFixture]
    public class UserControllerTests
    {
        private UserController _controller;
        private Mock<IUserRepo> _userRepoMock;

        [SetUp]
        public void Setup()
        {
            _userRepoMock = new Mock<IUserRepo>();
            _controller = new UserController(_userRepoMock.Object);
        }

        [Test]
        public async Task GetAll_ReturnsOkResultWithUsers()
        {
            var users = new List<User>
            {
                new User { UserName = "user1" },
                new User { UserName = "user2" }
            };
            _userRepoMock.Setup(repo => repo.GetAllUsers()).ReturnsAsync(users);

            var result = await _controller.GetAll();

            Assert.IsInstanceOf<OkObjectResult>(result);
            Assert.AreEqual(users, (result as OkObjectResult).Value);
        }

        [Test]
        public async Task GetOne_WithValidUsername_ReturnsOkResultWithUser()
        {
            var username = "user1";
            var user = new User { UserName = username };
            _userRepoMock.Setup(repo => repo.GetUserByUsername(username)).ReturnsAsync(user);

            var result = await _controller.GetOne(username);

            Assert.IsInstanceOf<OkObjectResult>(result);
            Assert.AreEqual(user, (result as OkObjectResult).Value);
        }

        [Test]
        public async Task GetOne_WithInvalidUsername_ReturnsNotFoundResult()
        {
            var username = "user1";
            _userRepoMock.Setup(repo => repo.GetUserByUsername(username)).ThrowsAsync(new Exception("User not found"));

            var result = await _controller.GetOne(username);

            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            Assert.AreEqual("User not found", (result as NotFoundObjectResult).Value);
        }

        [Test]
        public async Task RegisterUser_WithValidUser_ReturnsCreatedResultWithUser()
        {
            var user = new User { UserName = "user1" };

            var result = await _controller.RegisterUser(user);

            Assert.IsInstanceOf<CreatedResult>(result);
            var createdResult = result as CreatedResult;
            Assert.AreEqual($"api/user/{user.UserName}", createdResult.Location);
            Assert.AreEqual(user, createdResult.Value);
        }

        [Test]
        public async Task ForgotPass_WithValidUser_ReturnsOkResultWithUser()
        {
            var user = new User { UserName = "user1" };

            var result = await _controller.ForgotPass(user);

            Assert.IsInstanceOf<OkObjectResult>(result);
            Assert.AreEqual(user, (result as OkObjectResult).Value);
        }

        [Test]
        public async Task Delete_WithValidUsername_ReturnsOkResult()
        {
            var username = "user1";

            var result = await _controller.Delete(username);

            Assert.IsInstanceOf<OkResult>(result);
        }

        [Test]
        public async Task Login_WithValidUser_ReturnsOkResultWithUser()
        {
            var user = new User { UserName = "user1" };

            var result = await _controller.Login(user);

            Assert.IsInstanceOf<OkObjectResult>(result);
            Assert.AreEqual(user, (result as OkObjectResult).Value);
        }

        [Test]
        public async Task Login_WithInvalidUser_ReturnsUnauthorizedResult()
        {
            var user = new User { UserName = "user1" };
            _userRepoMock.Setup(repo => repo.Login(user)).ThrowsAsync(new Exception("Invalid credentials"));

            var result = await _controller.Login(user);

            Assert.IsInstanceOf<UnauthorizedObjectResult>(result);
            Assert.AreEqual("Invalid credentials", (result as UnauthorizedObjectResult).Value);
        }
    }
}