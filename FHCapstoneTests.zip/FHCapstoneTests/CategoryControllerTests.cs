﻿using NUnit.Framework;
using Moq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using webapi.Controllers;
using FHSquareLibrary.Models;
using FHSquareLibrary.Repos;

namespace YourTestProjectName
{
    [TestFixture]
    public class CategoryControllerTests
    {
        private CategoryController _controller;
        private Mock<ICategoryRepo> _categoryRepoMock;

        [SetUp]
        public void Setup()
        {
            _categoryRepoMock = new Mock<ICategoryRepo>();
            _controller = new CategoryController(_categoryRepoMock.Object);
        }

        [Test]
        public async Task GetAllCategory_ReturnsOkResultWithCategories()
        {
            var categories = new List<Category>
            {
                new Category { CategoryId = 1, CategoryName = "Category1" },
                new Category { CategoryId = 2, CategoryName = "Category2" }
            };
            _categoryRepoMock.Setup(repo => repo.GetAllCategories()).ReturnsAsync(categories);

            var result = await _controller.GetAllCategory();

            Assert.IsInstanceOf<OkObjectResult>(result);
            Assert.AreEqual(categories, (result as OkObjectResult).Value);
        }

        [Test]
        public async Task GetCategoryById_WithValidCategoryId_ReturnsOkResultWithCategory()
        {
            var categoryId = 1;
            var category = new Category { CategoryId = categoryId, CategoryName = "Category1" };
            _categoryRepoMock.Setup(repo => repo.GetCategoryById(categoryId)).ReturnsAsync(category);

            var result = await _controller.GetCategoryById(categoryId);

            Assert.IsInstanceOf<OkObjectResult>(result);
            Assert.AreEqual(category, (result as OkObjectResult).Value);
        }

        [Test]
        public async Task GetCategoryById_WithInvalidCategoryId_ReturnsNotFoundResult()
        {
            var categoryId = 1;
            _categoryRepoMock.Setup(repo => repo.GetCategoryById(categoryId)).ThrowsAsync(new Exception("Category not found"));

            var result = await _controller.GetCategoryById(categoryId);

            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            Assert.AreEqual("Category not found", (result as NotFoundObjectResult).Value);
        }

        [Test]
        public async Task GetCategoryByName_WithValidCategoryName_ReturnsOkResultWithCategory()
        {
            var categoryName = "Category1";
            var category = new Category { CategoryId = 1, CategoryName = categoryName };
            _categoryRepoMock.Setup(repo => repo.GetCategoryByName(categoryName)).ReturnsAsync(category);

            var result = await _controller.GetCategoryByName(categoryName);

            Assert.IsInstanceOf<OkObjectResult>(result);
            Assert.AreEqual(category, (result as OkObjectResult).Value);
        }

        [Test]
        public async Task GetCategoryByName_WithInvalidCategoryName_ReturnsNotFoundResult()
        {
            var categoryName = "Category1";
            _categoryRepoMock.Setup(repo => repo.GetCategoryByName(categoryName)).ThrowsAsync(new Exception("Category not found"));

            var result = await _controller.GetCategoryByName(categoryName);

            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            Assert.AreEqual("Category not found", (result as NotFoundObjectResult).Value);
        }

        [Test]
        public async Task Insert_WithValidCategory_ReturnsCreatedResultWithCategory()
        {
            var category = new Category { CategoryId = 1, CategoryName = "Category1" };

            var result = await _controller.Insert(category);

            Assert.IsInstanceOf<CreatedResult>(result);
            var createdResult = result as CreatedResult;
            Assert.AreEqual($"api/category/{category.CategoryId}", createdResult.Location);
            Assert.AreEqual(category, createdResult.Value);
        }

        [Test]
        public async Task Update_WithValidCategoryIdAndCategory_ReturnsOkResult()
        {
            var categoryId = 1;
            var category = new Category { CategoryId = categoryId, CategoryName = "UpdatedCategory" };

            var result = await _controller.Update(categoryId, category);

            Assert.IsInstanceOf<OkResult>(result);
        }

        [Test]
        public async Task Delete_WithValidCategoryId_ReturnsOkResult()
        {
            var categoryId = 1;

            var result = await _controller.Delete(categoryId);

            Assert.IsInstanceOf<OkResult>(result);
        }
    }
}