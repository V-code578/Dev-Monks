﻿using FHSquareLibrary.Models;
using FHSquareLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using webapi.Controllers;

namespace FHCapstoneTests
{
    [TestFixture]
    public class ProductControllerTests
    {
        private ProductController _controller;
        private Mock<IProductRepo> _productRepoMock;

        [SetUp]
        public void Setup()
        {
            _productRepoMock = new Mock<IProductRepo>();
            _controller = new ProductController(_productRepoMock.Object);
        }

        [Test]
        public async Task GetAllProducts_ReturnsListOfProducts()
        {
            // Arrange
            var products = new List<Product>
        {
            new Product { ProductId = 1, ProductName = "Product1" },
            new Product { ProductId = 2, ProductName = "Product2" }
        };
            _productRepoMock.Setup(repo => repo.GetAllProducts()).ReturnsAsync(products);

            // Act
            var result = await _controller.GetAllProducts();

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(products, okResult.Value);
        }

        [Test]
        public async Task GetProductById_WithValidProductId_ReturnsProduct()
        {
            // Arrange
            var productId = 1;
            var product = new Product { ProductId = productId, ProductName = "Product1" };
            _productRepoMock.Setup(repo => repo.GetProductById(productId)).ReturnsAsync(product);

            // Act
            var result = await _controller.GetProductById(productId);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(product, okResult.Value);
        }

        [Test]
        public async Task GetProductById_WithInvalidProductId_ReturnsNotFound()
        {
            // Arrange
            var productId = 1;
            _productRepoMock.Setup(repo => repo.GetProductById(productId)).ThrowsAsync(new Exception("Product not found"));

            // Act
            var result = await _controller.GetProductById(productId);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            var notFoundResult = result as NotFoundObjectResult;
            Assert.AreEqual("Product not found", notFoundResult.Value);
        }

        [Test]
        public async Task GetProductByName_WithValidProductName_ReturnsProduct()
        {
            // Arrange
            var productName = "Product1";
            var product = new Product { ProductId = 1, ProductName = productName };
            _productRepoMock.Setup(repo => repo.GetProductByName(productName)).ReturnsAsync(product);

            // Act
            var result = await _controller.GetProductByName(productName);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(product, okResult.Value);
        }

        [Test]
        public async Task GetProductByName_WithInvalidProductName_ReturnsNotFound()
        {
            // Arrange
            var productName = "Product1";
            _productRepoMock.Setup(repo => repo.GetProductByName(productName)).ThrowsAsync(new Exception("Product not found"));

            // Act
            var result = await _controller.GetProductByName(productName);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            var notFoundResult = result as NotFoundObjectResult;
            Assert.AreEqual("Product not found", notFoundResult.Value);
        }

        [Test]
        public async Task GetProductsByCategory_WithValidCategoryId_ReturnsListOfProducts()
        {
            // Arrange
            var categoryId = 1;
            var products = new List<Product>
        {
            new Product { ProductId = 1, ProductName = "Product1" },
            new Product { ProductId = 2, ProductName = "Product2" }
        };
            _productRepoMock.Setup(repo => repo.GetProductsByCategory(categoryId)).ReturnsAsync(products);

            // Act
            var result = await _controller.GetProductsByCategory(categoryId);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(products, okResult.Value);
        }

        [Test]
        public async Task GetProductsByCategory_WithInvalidCategoryId_ReturnsNotFound()
        {
            // Arrange
            var categoryId = 1;
            _productRepoMock.Setup(repo => repo.GetProductsByCategory(categoryId)).ThrowsAsync(new Exception("Category not found"));

            // Act
            var result = await _controller.GetProductsByCategory(categoryId);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            var notFoundResult = result as NotFoundObjectResult;
            Assert.AreEqual("Category not found", notFoundResult.Value);
        }

        [Test]
        public async Task AddProduct_WithValidProduct_ReturnsCreatedResultWithProduct()
        {
            // Arrange
            var product = new Product { ProductId = 1, ProductName = "Product1" };

            // Act
            var result = await _controller.AddProduct(product);

            // Assert
            Assert.IsInstanceOf<CreatedResult>(result);
            var createdResult = result as CreatedResult;
            Assert.AreEqual($"api/product/{product.ProductId}", createdResult.Location);
            Assert.AreEqual(product, createdResult.Value);
        }

        [Test]
        public async Task UpdateProduct_WithValidProductId_ReturnsUpdatedProduct()
        {
            // Arrange
            var productId = 1;
            var updatedProduct = new Product { ProductId = productId, ProductName = "UpdatedProduct" };

            // Act
            var result = await _controller.UpdateProduct(productId, updatedProduct);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(updatedProduct, okResult.Value);
        }

        [Test]
        public async Task DeleteProduct_WithValidProductId_ReturnsOkResult()
        {
            // Arrange
            var productId = 1;

            // Act
            var result = await _controller.DeleteProduct(productId);

            // Assert
            Assert.IsInstanceOf<OkResult>(result);
        }
    }
}
