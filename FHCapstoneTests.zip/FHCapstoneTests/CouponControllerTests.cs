﻿using FHSquareLibrary.Models;
using FHSquareLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using webapi.Controllers;

namespace webapi.tests
{
    [TestFixture]
    public class CouponControllerTests
    {
        private Mock<ICouponRepo> mockCouponRepo;
        private CouponController couponController;

        [SetUp]
        public void Setup()
        {
            mockCouponRepo = new Mock<ICouponRepo>();
            couponController = new CouponController(mockCouponRepo.Object);
        }

        [Test]
        public async Task GetAll_ReturnsOkResultWithListOfCoupons()
        {
            // Arrange
            List<Coupon> expectedCoupons = new List<Coupon>()
            {
                new Coupon { CouponId = 1, CouponCode = "CODE1" },
                new Coupon { CouponId = 2, CouponCode = "CODE2" }
            };
            mockCouponRepo.Setup(repo => repo.GetAllCoupons()).ReturnsAsync(expectedCoupons);

            // Act
            ActionResult result = await couponController.GetAll();

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            OkObjectResult okResult = (OkObjectResult)result;
            Assert.AreEqual(expectedCoupons, okResult.Value);
        }

        [Test]
        public async Task GetById_WithValidCouponId_ReturnsOkResultWithCoupon()
        {
            // Arrange
            int couponId = 1;
            Coupon expectedCoupon = new Coupon { CouponId = couponId, CouponCode = "CODE1" };
            mockCouponRepo.Setup(repo => repo.GetCouponById(couponId)).ReturnsAsync(expectedCoupon);

            // Act
            ActionResult result = await couponController.GetById(couponId);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            OkObjectResult okResult = (OkObjectResult)result;
            Assert.AreEqual(expectedCoupon, okResult.Value);
        }

        [Test]
        public async Task GetById_WithInvalidCouponId_ReturnsNotFoundResult()
        {
            // Arrange
            int couponId = 1;
            string errorMessage = "Coupon not found.";
            mockCouponRepo.Setup(repo => repo.GetCouponById(couponId)).ThrowsAsync(new Exception(errorMessage));

            // Act
            ActionResult result = await couponController.GetById(couponId);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            NotFoundObjectResult notFoundResult = (NotFoundObjectResult)result;
            Assert.AreEqual(errorMessage, notFoundResult.Value);
        }

        [Test]
        public async Task Insert_ReturnsCreatedResultWithInsertedCoupon()
        {
            // Arrange
            Coupon couponToInsert = new Coupon { CouponId = 1, CouponCode = "CODE1" };
            mockCouponRepo.Setup(repo => repo.AddCoupon(couponToInsert)).Returns(Task.CompletedTask);

            // Act
            ActionResult result = await couponController.Insert(couponToInsert);

            // Assert
            Assert.IsInstanceOf<CreatedResult>(result);
            CreatedResult createdResult = (CreatedResult)result;
            Assert.AreEqual($"api/Coupon/{couponToInsert.CouponId}", createdResult.Location);
            Assert.AreEqual(couponToInsert, createdResult.Value);
        }

        [Test]
        public async Task Delete_ReturnsOkResult()
        {
            // Arrange
            int couponId = 1;
            mockCouponRepo.Setup(repo => repo.DeleteCoupon(couponId)).Returns(Task.CompletedTask);

            // Act
            ActionResult result = await couponController.Delete(couponId);

            // Assert
            Assert.IsInstanceOf<OkResult>(result);
        }
    }
}