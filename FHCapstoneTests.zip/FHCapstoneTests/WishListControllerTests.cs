﻿using FHSquareLibrary.Models;
using FHSquareLibrary.Repos;
using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using webapi.Controllers;

namespace YourTestProjectNamespace
{
    [TestFixture]
    public class WishListControllerTests
    {
        [Test]
        public async Task GetWishListById_ReturnsOkResult()
        {
            // Arrange
            int wishListId = 1;
            var mockRepo = new Mock<IWishListRepo>();
            var wishlist = new WishList { /* set up the properties */ };
            mockRepo.Setup(repo => repo.GetWishListById(wishListId)).ReturnsAsync(wishlist);
            var controller = new WishListController(mockRepo.Object);

            // Act
            var result = await controller.GetWishListById(wishListId);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.AreEqual(wishlist, okResult.Value);
        }

        [Test]
        public async Task GetWishListById_ReturnsNotFoundResult()
        {
            // Arrange
            int wishListId = 1;
            var mockRepo = new Mock<IWishListRepo>();
            mockRepo.Setup(repo => repo.GetWishListById(wishListId)).ThrowsAsync(new Exception("WishList not found."));
            var controller = new WishListController(mockRepo.Object);

            // Act
            var result = await controller.GetWishListById(wishListId);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            var notFoundResult = (NotFoundObjectResult)result;
            Assert.AreEqual("WishList not found.", notFoundResult.Value);
        }

        [Test]
        public async Task GetWishListByUserName_ReturnsOkResult()
        {
            // Arrange
            string userName = "testUser";
            var mockRepo = new Mock<IWishListRepo>();
            var wishLists = new List<WishList> { /* set up the wish lists */ };
            mockRepo.Setup(repo => repo.GetWishListByUserName(userName)).ReturnsAsync(wishLists);
            var controller = new WishListController(mockRepo.Object);

            // Act
            var result = await controller.GetWishListByUserName(userName);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = (OkObjectResult)result;
            Assert.AreEqual(wishLists, okResult.Value);
        }

        [Test]
        public async Task GetWishListByUserName_ReturnsNotFoundResult()
        {
            // Arrange
            string userName = "testUser";
            var mockRepo = new Mock<IWishListRepo>();
            mockRepo.Setup(repo => repo.GetWishListByUserName(userName)).ThrowsAsync(new Exception("WishLists not found."));
            var controller = new WishListController(mockRepo.Object);

            // Act
            var result = await controller.GetWishListByUserName(userName);

            // Assert
            Assert.IsInstanceOf<NotFoundObjectResult>(result);
            var notFoundResult = (NotFoundObjectResult)result;
            Assert.AreEqual("WishLists not found.", notFoundResult.Value);
        }

        [Test]
        public async Task AddToWishList_ReturnsCreatedResult()
        {
            // Arrange
            var mockRepo = new Mock<IWishListRepo>();
            var wishList = new WishList { /* set up the wish list */ };
            mockRepo.Setup(repo => repo.AddToWishList(wishList)).Returns(Task.CompletedTask);
            var controller = new WishListController(mockRepo.Object);

            // Act
            var result = await controller.AddToWishList(wishList);

            // Assert
            Assert.IsInstanceOf<CreatedAtActionResult>(result);
            var createdAtActionResult = (CreatedAtActionResult)result;
            Assert.AreEqual($"api/wishlist/{wishList.WishListId}", createdAtActionResult.ActionName);
            Assert.AreEqual(wishList, createdAtActionResult.Value);
        }

        [Test]
        public async Task RemoveFromWishList_ReturnsOkResult()
        {
            // Arrange
            int wishListId = 1;
            var mockRepo = new Mock<IWishListRepo>();
            mockRepo.Setup(repo => repo.RemoveFromWishList(wishListId)).Returns(Task.CompletedTask);
            var controller = new WishListController(mockRepo.Object);

            // Act
            var result = await controller.RemoveFromWishList(wishListId);

            // Assert
            Assert.IsInstanceOf<OkResult>(result);
        }

        [Test]
        public async Task ClearWishList_ReturnsOkResult()
        {
            // Arrange
            string userName = "testUser";
            var mockRepo = new Mock<IWishListRepo>();
            mockRepo.Setup(repo => repo.ClearWishList(userName)).Returns(Task.CompletedTask);
            var controller = new WishListController(mockRepo.Object);

            // Act
            var result = await controller.ClearWishList(userName);

            // Assert
            Assert.IsInstanceOf<OkResult>(result);
        }
    }
}
